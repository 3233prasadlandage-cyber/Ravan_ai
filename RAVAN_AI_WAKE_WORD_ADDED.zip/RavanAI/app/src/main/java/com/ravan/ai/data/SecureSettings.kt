package com.ravan.ai.data

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/** All settings (including the backend token) live in Android Keystore-backed encrypted preferences. */
class SecureSettings(context: Context) {
    private val prefs: SharedPreferences = create(context.applicationContext)

    var backendUrl: String
        get() = prefs.getString("backend_url", "") ?: ""
        set(value) { prefs.edit().putString("backend_url", value.trim().trimEnd('/')).apply() }

    var appToken: String
        get() = prefs.getString("app_token", "") ?: ""
        set(value) { prefs.edit().putString("app_token", value.trim()).apply() }

    /** "auto", "mr-IN", "hi-IN" or "en-IN" */
    var language: String
        get() = prefs.getString("language", "auto") ?: "auto"
        set(value) { prefs.edit().putString("language", value).apply() }

    var memoryEnabled: Boolean
        get() = prefs.getBoolean("memory", true)
        set(value) { prefs.edit().putBoolean("memory", value).apply() }

    var speakReplies: Boolean
        get() = prefs.getBoolean("speak", true)
        set(value) { prefs.edit().putBoolean("speak", value).apply() }

    var wakeWordEnabled: Boolean
        get() = prefs.getBoolean("wake_word_enabled", false)
        set(value) { prefs.edit().putBoolean("wake_word_enabled", value).apply() }

    var busyMode: Boolean
        get() = prefs.getBoolean("busy", false)
        set(value) { prefs.edit().putBoolean("busy", value).apply() }

    var autoSms: Boolean
        get() = prefs.getBoolean("auto_sms", false)
        set(value) { prefs.edit().putBoolean("auto_sms", value).apply() }

    /** Optional cloud-telephony number callers can ring to talk to the AI. */
    var forwardNumber: String
        get() = prefs.getString("forward_number", "") ?: ""
        set(value) { prefs.edit().putString("forward_number", value.trim()).apply() }

    var searchFolderUri: String
        get() = prefs.getString("search_folder", "") ?: ""
        set(value) { prefs.edit().putString("search_folder", value).apply() }

    fun lastSmsAt(number: String): Long = prefs.getLong("sms_$number", 0L)

    fun markSmsSent(number: String) {
        prefs.edit().putLong("sms_$number", System.currentTimeMillis()).apply()
    }

    companion object {
        private fun create(context: Context): SharedPreferences {
            val key = MasterKey.Builder(context)
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                .build()
            return EncryptedSharedPreferences.create(
                context,
                "ravan_secure_prefs",
                key,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        }
    }
}
