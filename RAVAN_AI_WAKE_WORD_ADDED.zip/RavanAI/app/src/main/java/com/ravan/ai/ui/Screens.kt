@file:OptIn(ExperimentalMaterial3Api::class)

package com.ravan.ai.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ravan.ai.MainViewModel
import com.ravan.ai.automation.Action
import com.ravan.ai.data.CallLogEntity
import com.ravan.ai.data.MessageEntity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// ------------------------------------------------------------------ Dashboard

@Composable
fun DashboardScreen(vm: MainViewModel, actions: HostActions) {
    val ui by vm.ui.collectAsState()
    val msgs by vm.messages.collectAsState()
    val perm by vm.perm.collectAsState()
    val prefs by vm.prefs.collectAsState()
    val calls by vm.calls.collectAsState()
    val speaking by vm.speaking.collectAsState()

    val shortcuts = remember {
        listOf(
            Triple(Icons.Default.CameraAlt, "Camera", Action("camera")),
            Triple(Icons.Default.PlayCircle, "YouTube", Action("youtube")),
            Triple(Icons.Default.Settings, "Settings", Action("settings", mapOf("screen" to "main"))),
            Triple(Icons.Default.Wifi, "Wi-Fi", Action("settings", mapOf("screen" to "wifi"))),
            Triple(Icons.Default.Alarm, "Alarms", Action("show_alarms")),
            Triple(Icons.Default.Bluetooth, "Bluetooth", Action("settings", mapOf("screen" to "bluetooth")))
        )
    }

    LazyColumn(
        Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { RavanLogo() }

        item {
            RCard {
                Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                    MicButton(listening = ui.listening) {
                        if (!perm.mic) actions.requestMic()
                        else if (ui.listening) vm.stopListening()
                        else vm.startListening()
                    }
                    val line = when {
                        ui.listening -> "Listening…"
                        ui.thinking -> "Thinking…"
                        speaking -> "Speaking…"
                        !perm.mic -> "Tap to allow the microphone"
                        else -> "Tap to speak in Marathi, Hindi or English"
                    }
                    Text(line, color = if (ui.listening) RavanColors.Red else RavanColors.Text, fontSize = 15.sp)
                    if (ui.partial.isNotBlank()) {
                        Spacer(Modifier.height(6.dp))
                        Text(ui.partial, color = RavanColors.Muted, fontSize = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    }
                    if (speaking) {
                        Spacer(Modifier.height(10.dp))
                        GhostButton("Stop speaking") { vm.stopSpeaking() }
                    }
                    Spacer(Modifier.height(12.dp))
                    LanguageChips(prefs.language) { lang -> vm.edit { language = lang } }
                }
            }
        }

        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                SectionTitle("Quick actions")
                shortcuts.chunked(3).forEach { row ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        row.forEach { (icon, label, act) ->
                            ShortcutTile(icon, label, Modifier.weight(1f)) { vm.runShortcut(act) }
                        }
                    }
                }
            }
        }

        item {
            RCard {
                SectionTitle("Smart Call Assistant")
                Spacer(Modifier.height(8.dp))
                StatusRow(perm.screening, if (perm.screening) "Call screening enabled" else "Call screening not enabled")
                StatusRow(prefs.busy, if (prefs.busy) "Busy mode ON" else "Busy mode OFF")
                StatusRow(
                    prefs.autoSms && perm.sms,
                    if (prefs.autoSms) (if (perm.sms) "Auto-reply SMS ON" else "Auto-reply SMS needs SMS permission") else "Auto-reply SMS OFF"
                )
                Text("${calls.size} call entries in log", color = RavanColors.Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
                if (!perm.screening) {
                    Spacer(Modifier.height(10.dp))
                    RButton("Enable call screening") { actions.requestScreeningRole() }
                }
            }
        }

        item {
            RCard {
                SectionTitle("Permissions")
                PermRow("Microphone", "Voice commands. Audio goes to Android's speech service only while you listen.", perm.mic, "Allow", actions.requestMic)
                PermRow("Notifications", "Reminders and call alerts. Automatic on Android 11.", perm.notif, "Allow", actions.requestNotif)
                PermRow("SMS (optional)", "Only to send the busy auto-reply you switch on.", perm.sms, "Allow", actions.requestSms)
                PermRow("Call screening", "Shows RAVAN the caller number. It cannot answer calls or hear audio.", perm.screening, "Enable", actions.requestScreeningRole)
            }
        }

        item { SectionTitle("Recent conversations") }
        val recent = msgs.filter { it.role != "action" }.takeLast(4).reversed()
        if (recent.isEmpty()) {
            item { Text("Nothing yet. Say or type something to begin.", color = RavanColors.Muted, fontSize = 13.sp) }
        } else {
            items(recent, key = { it.id }) { m ->
                RCard {
                    Text(if (m.role == "user") "You" else "RAVAN", color = RavanColors.Red, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Text(m.text, color = RavanColors.Text, fontSize = 14.sp, maxLines = 3, overflow = TextOverflow.Ellipsis)
                }
            }
        }
    }
}

// ------------------------------------------------------------------ Chat

@Composable
fun ChatScreen(vm: MainViewModel, actions: HostActions) {
    val msgs by vm.messages.collectAsState()
    val ui by vm.ui.collectAsState()
    val perm by vm.perm.collectAsState()
    val speaking by vm.speaking.collectAsState()
    var text by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    LaunchedEffect(msgs.size) {
        if (msgs.isNotEmpty()) listState.animateScrollToItem(msgs.size - 1)
    }

    Column(Modifier.fillMaxSize()) {
        LazyColumn(
            Modifier
                .weight(1f)
                .fillMaxWidth(),
            state = listState,
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (msgs.isEmpty()) {
                item { Text("Ask anything, translate, or give a command like \"उद्या सकाळी ७ वाजता अलार्म लाव\".", color = RavanColors.Muted) }
            }
            items(msgs, key = { it.id }) { m -> Bubble(m) }
            if (ui.thinking) item { Text("RAVAN is thinking…", color = RavanColors.Muted, fontSize = 13.sp) }
        }
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Message in Marathi, Hindi or English") },
                maxLines = 4,
                shape = RoundedCornerShape(24.dp),
                colors = ravanFieldColors()
            )
            IconButton(onClick = {
                if (!perm.mic) actions.requestMic()
                else if (ui.listening) vm.stopListening()
                else vm.startListening()
            }) {
                Icon(
                    if (ui.listening) Icons.Default.Stop else Icons.Default.Mic,
                    contentDescription = "Voice input",
                    tint = if (ui.listening) RavanColors.Red else RavanColors.Text
                )
            }
            if (speaking) {
                IconButton(onClick = { vm.stopSpeaking() }) {
                    Icon(Icons.Default.Stop, contentDescription = "Stop speaking", tint = RavanColors.Amber)
                }
            }
            IconButton(
                onClick = {
                    vm.submit(text)
                    text = ""
                },
                enabled = text.isNotBlank()
            ) {
                Icon(
                    Icons.AutoMirrored.Filled.Send,
                    contentDescription = "Send",
                    tint = if (text.isNotBlank()) RavanColors.Red else RavanColors.Muted
                )
            }
        }
    }
}

@Composable
private fun Bubble(m: MessageEntity) {
    val isUser = m.role == "user"
    val isAction = m.role == "action"
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
    ) {
        Box(
            Modifier
                .widthIn(max = 300.dp)
                .background(
                    when {
                        isUser -> RavanColors.RedDeep
                        isAction -> RavanColors.Bg
                        else -> RavanColors.Card
                    },
                    RoundedCornerShape(18.dp)
                )
                .border(1.dp, if (isAction) RavanColors.Red else RavanColors.Border, RoundedCornerShape(18.dp))
                .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            Text(
                m.text,
                color = if (isAction) RavanColors.Muted else RavanColors.Text,
                fontSize = if (isAction) 13.sp else 15.sp
            )
        }
    }
}

// ------------------------------------------------------------------ Calls

@Composable
fun CallsScreen(vm: MainViewModel, actions: HostActions) {
    val perm by vm.perm.collectAsState()
    val prefs by vm.prefs.collectAsState()
    val calls by vm.calls.collectAsState()
    var forward by remember(prefs.forward) { mutableStateOf(prefs.forward) }

    LazyColumn(
        Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { Text("Smart Call Assistant", color = RavanColors.Text, fontSize = 22.sp, fontWeight = FontWeight.Black) }

        item {
            RCard {
                StatusRow(perm.screening, if (perm.screening) "Call screening enabled" else "Call screening not enabled")
                if (!perm.screening) {
                    Spacer(Modifier.height(6.dp))
                    RButton("Enable call screening") { actions.requestScreeningRole() }
                }
                Spacer(Modifier.height(8.dp))
                SwitchRow("Busy mode", "Alert me about every incoming call while I'm busy", prefs.busy) { on ->
                    if (on && !perm.screening) actions.requestScreeningRole()
                    vm.edit { busyMode = on }
                }
                SwitchRow("Auto-reply SMS", "Sends one SMS per caller (max every 30 min) saying an AI assistant is relaying messages", prefs.autoSms) { on ->
                    if (on && !perm.sms) actions.requestSms()
                    vm.edit { autoSms = on }
                }
            }
        }

        item {
            RCard {
                SectionTitle("What Android allows")
                Spacer(Modifier.height(6.dp))
                Text(
                    "A normal Android app cannot directly answer a SIM call and read both sides of its audio. RAVAN can show call alerts, but a real AI conversation needs a supported cloud voice number and carrier-approved call forwarding. " +
                        "This project includes a Twilio-compatible, turn-by-turn AI receptionist backend. Availability in India depends on the provider and carrier; check local number, toll-free, forwarding and usage restrictions before enabling it. " +
                        "The caller is told it is an AI, and only a short text summary plus caller number is saved by this project; the voice provider may process call data. This can have charges.",
                    color = RavanColors.Muted, fontSize = 13.sp
                )
            }
        }

        item {
            RCard {
                SectionTitle("Cloud AI voice number (optional)")
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = forward,
                    onValueChange = { forward = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Cloud provider voice number") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    colors = ravanFieldColors()
                )
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    RButton("Save") { vm.edit { forwardNumber = forward }; vm.postStatus("Saved.") }
                    GhostButton("Sync summaries") { vm.syncCalls() }
                }
                Spacer(Modifier.height(10.dp))
                GhostButton("Hear greeting") { vm.previewGreeting() }
            }
        }

        item { SectionTitle("Call log") }
        if (calls.isEmpty()) {
            item { Text("No calls yet.", color = RavanColors.Muted, fontSize = 13.sp) }
        } else {
            items(calls, key = { it.id }) { c -> CallRow(c) }
        }
    }
}

@Composable
private fun CallRow(c: CallLogEntity) {
    val time = SimpleDateFormat("dd MMM, HH:mm", Locale.getDefault()).format(Date(c.ts))
    RCard {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(c.number, color = RavanColors.Text, fontWeight = FontWeight.SemiBold)
            Text(time, color = RavanColors.Muted, fontSize = 12.sp)
        }
        Text(c.purpose, color = RavanColors.Red, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
        Text(c.summary, color = RavanColors.Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 2.dp))
    }
}

// ------------------------------------------------------------------ Agent tools

@Composable
fun AgentScreen(vm: MainViewModel, actions: HostActions) {
    val ui by vm.ui.collectAsState()
    var appName by remember { mutableStateOf("") }

    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 16.dp),
        contentPadding = PaddingValues(vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text("RAVAN Agent", color = RavanColors.Text, fontSize = 22.sp, fontWeight = FontWeight.Black)
            Text("Give RAVAN a multi-step task in Chat. It can plan up to five supported steps, show the plan for review, run approved steps in order and stop if a step fails or hands control to another app.", color = RavanColors.Muted, fontSize = 13.sp)
        }
        item {
            RCard {
                SectionTitle("Find and install an app")
                Spacer(Modifier.height(6.dp))
                OutlinedTextField(
                    value = appName,
                    onValueChange = { appName = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("App name, e.g. CapCut") },
                    singleLine = true,
                    colors = ravanFieldColors()
                )
                Spacer(Modifier.height(8.dp))
                RButton("Search in Play Store") {
                    vm.searchAppInStore(appName)
                }
                Text("RAVAN opens the official store search. You review the app and tap Install; it cannot silently install apps.", color = RavanColors.Muted, fontSize = 12.sp)
            }
        }
        item {
            RCard {
                SectionTitle("Photo understanding (on-device)")
                Spacer(Modifier.height(6.dp))
                Text("RAVAN can count visible faces and label common objects/scenes in a selected photo. Processing uses on-device ML Kit; it does not identify a person's name or match someone's identity across pictures.", color = RavanColors.Muted, fontSize = 12.sp)
                Spacer(Modifier.height(8.dp))
                RButton("Choose photo and analyze") { actions.pickPhoto() }
                if (ui.photoAnalysis.isNotBlank()) {
                    Text(ui.photoAnalysis, color = RavanColors.Text, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
                }
            }
        }
        item {
            var creatorTitle by remember { mutableStateOf("") }
            var creatorFormat by remember { mutableStateOf("LANDSCAPE") }
            var creatorFilter by remember { mutableStateOf("NONE") }
            var imageSeconds by remember { mutableStateOf("5") }
            var muteOriginal by remember { mutableStateOf(false) }
            RCard {
                SectionTitle("RAVAN Creator Studio — multi-clip video maker")
                Text(
                    "Add up to 20 photos/videos. RAVAN joins them in order, can turn photos into timed scenes, mix a music track, apply a colour preset and add a title overlay. Everything renders locally on your phone.",
                    color = RavanColors.Muted, fontSize = 12.sp
                )
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    RButton("Add photos / videos") { actions.pickCreatorAssets() }
                    GhostButton("Clear timeline") { vm.clearCreatorAssets() }
                }
                Text(
                    "Timeline assets: ${ui.creatorMediaUris.size}/20",
                    color = RavanColors.Green, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp)
                )
                if (ui.creatorMediaUris.isNotEmpty()) {
                    ui.creatorMediaUris.forEachIndexed { index, uri ->
                        Text("${index + 1}. ${uri.substringAfterLast('/').take(48)}", color = RavanColors.Muted, fontSize = 11.sp)
                    }
                }
                Spacer(Modifier.height(10.dp))
                RButton("Choose background music") { actions.pickCreatorMusic() }
                Text(
                    if (ui.creatorMusicUri.isBlank()) "No background music selected." else "Background music selected.",
                    color = RavanColors.Muted, fontSize = 11.sp
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = creatorTitle,
                    onValueChange = { creatorTitle = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Video title / on-screen caption") },
                    minLines = 1,
                    maxLines = 2,
                    colors = ravanFieldColors()
                )
                Text("Output format", color = RavanColors.Text, fontSize = 13.sp, modifier = Modifier.padding(top = 10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = creatorFormat == "LANDSCAPE", onClick = { creatorFormat = "LANDSCAPE" }, label = { Text("YouTube 16:9") })
                    FilterChip(selected = creatorFormat == "SHORTS", onClick = { creatorFormat = "SHORTS" }, label = { Text("Shorts 9:16") })
                }
                Text("Colour effects", color = RavanColors.Text, fontSize = 13.sp, modifier = Modifier.padding(top = 10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("NONE", "CINEMATIC", "B&W", "BRIGHT", "INVERT").forEach { effect ->
                        FilterChip(
                            selected = creatorFilter == effect,
                            onClick = { creatorFilter = effect },
                            label = { Text(effect, fontSize = 10.sp) }
                        )
                    }
                }
                OutlinedTextField(
                    value = imageSeconds,
                    onValueChange = { imageSeconds = it.filter(Char::isDigit).take(2) },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Seconds per photo (2–12)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    colors = ravanFieldColors()
                )
                SwitchRow("Mute source video audio", "Keep selected background music only", muteOriginal) { muteOriginal = it }
                Spacer(Modifier.height(8.dp))
                RButton("Create / Export MP4", enabled = ui.creatorMediaUris.isNotEmpty() && !ui.creatorBusy) {
                    val seconds = imageSeconds.toIntOrNull()?.coerceIn(2, 12) ?: 5
                    vm.exportCreatorVideo(creatorTitle, creatorFilter, creatorFormat, seconds, muteOriginal)
                }
                if (ui.creatorBusy) Text("Rendering video on this phone. Keep RAVAN open while it exports.", color = RavanColors.Amber, fontSize = 12.sp)
                if (ui.creatorStatus.isNotBlank()) Text(ui.creatorStatus, color = RavanColors.Text, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
                if (ui.creatorOutputUri.isNotBlank()) {
                    RButton("Share finished video") { vm.shareCreatorVideo() }
                }
                Text(
                    "Note: this creates a real slideshow/clip-composition video. It is not text-to-video AI generation. Crossfade transitions, advanced VFX packs and generative motion need further engines or optional cloud services.",
                    color = RavanColors.Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp)
                )
            }
        }
        item {
            var youtubeTitle by remember { mutableStateOf("") }
            var youtubeDescription by remember { mutableStateOf("") }
            var youtubeTags by remember { mutableStateOf("") }
            RCard {
                SectionTitle("YouTube Channel Manager")
                Text(
                    "Prepare an upload-details pack here, copy it, then open official YouTube Studio. RAVAN does not change private channel/monetization settings without the official account flow; review every setting before publishing.",
                    color = RavanColors.Muted, fontSize = 12.sp
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = youtubeTitle, onValueChange = { youtubeTitle = it },
                    modifier = Modifier.fillMaxWidth(), label = { Text("YouTube video title") },
                    singleLine = true, colors = ravanFieldColors()
                )
                OutlinedTextField(
                    value = youtubeDescription, onValueChange = { youtubeDescription = it },
                    modifier = Modifier.fillMaxWidth(), label = { Text("Description") },
                    minLines = 3, maxLines = 5, colors = ravanFieldColors()
                )
                OutlinedTextField(
                    value = youtubeTags, onValueChange = { youtubeTags = it },
                    modifier = Modifier.fillMaxWidth(), label = { Text("Tags (comma-separated)") },
                    minLines = 1, maxLines = 2, colors = ravanFieldColors()
                )
                Spacer(Modifier.height(8.dp))
                RButton("Copy upload details") { vm.copyYouTubeUploadDetails(youtubeTitle, youtubeDescription, youtubeTags) }
                GhostButton("Open YouTube Studio") { actions.openYoutubeStudio() }
                GhostButton("Share latest RAVAN video") { vm.shareCreatorVideo() }
                Text(
                    "Monetization checklist: open Earn in YouTube Studio, review the requirements and channel policy status, then follow the official application steps. RAVAN can explain the checklist but cannot guarantee approval or switch monetization on for you. Direct API upload needs a Google Cloud OAuth client and your explicit YouTube upload authorization.",
                    color = RavanColors.Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp)
                )
            }
        }
        item {
            var trimStart by remember { mutableStateOf("0") }
            var trimEnd by remember { mutableStateOf("") }
            var muteAudio by remember { mutableStateOf(false) }
            var rotation by remember { mutableStateOf(0) }
            LaunchedEffect(ui.videoDurationSeconds) {
                if (ui.videoDurationSeconds > 0.0) {
                    trimEnd = String.format(Locale.US, "%.1f", ui.videoDurationSeconds)
                }
            }
            RCard {
                SectionTitle("RAVAN built-in video editor")
                Spacer(Modifier.height(6.dp))
                Text("This edits and exports the video inside RAVAN using the phone's media encoder. It does not just open CapCut. Select a clip, set start/end seconds, optionally mute audio or rotate, then export an MP4 to Movies/RAVAN AI.", color = RavanColors.Muted, fontSize = 12.sp)
                Spacer(Modifier.height(8.dp))
                RButton("Choose video") { actions.pickVideo() }
                if (ui.selectedVideoUri.isNotBlank()) {
                    Text("Selected: ${ui.selectedVideoUri.substringAfterLast('/').take(64)}", color = RavanColors.Green, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
                    if (ui.videoDurationSeconds > 0.0) {
                        Text("Duration: ${String.format(Locale.US, "%.1f", ui.videoDurationSeconds)} seconds", color = RavanColors.Muted, fontSize = 12.sp)
                    }
                }
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = trimStart,
                    onValueChange = { trimStart = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Start time (seconds)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    colors = ravanFieldColors()
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = trimEnd,
                    onValueChange = { trimEnd = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("End time (seconds)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    colors = ravanFieldColors()
                )
                SwitchRow("Mute original audio", "Remove the video's original audio track", muteAudio) { muteAudio = it }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    GhostButton("Rotate 90°") { rotation = (rotation + 90) % 360 }
                    Text("Rotation: ${rotation}°", color = RavanColors.Muted, fontSize = 12.sp)
                    GhostButton("Reset") { rotation = 0 }
                }
                Spacer(Modifier.height(8.dp))
                RButton("Edit and export MP4", enabled = ui.selectedVideoUri.isNotBlank() && !ui.videoBusy) {
                    vm.exportEditedVideo(trimStart, trimEnd, muteAudio, rotation)
                }
                if (ui.videoBusy) {
                    Text("Export in progress… Keep RAVAN open until it finishes.", color = RavanColors.Amber, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
                }
                if (ui.videoStatus.isNotBlank()) {
                    Text(ui.videoStatus, color = RavanColors.Text, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
                }
                if (ui.editedVideoUri.isNotBlank()) {
                    Spacer(Modifier.height(6.dp))
                    RButton("Share edited video") { vm.shareEditedVideo() }
                }
            }
        }
        item {
            RCard {
                SectionTitle("Scheduled messages")
                Text("Open Settings to schedule a WhatsApp draft reminder. WhatsApp still requires you to review and tap Send.", color = RavanColors.Muted, fontSize = 12.sp)
            }
        }
        item {
            RCard {
                SectionTitle("Level 3 task planning")
                Text("With the optional AI backend, RAVAN can turn a request into a short plan of up to five supported phone actions. Multi-step plans are shown for approval before execution. RAVAN records each result and stops on the first failure or when another app needs you to take over. It cannot bypass Android permissions or silently install apps, send WhatsApp messages, or control every third-party editor.", color = RavanColors.Muted, fontSize = 12.sp)
            }
        }
    }
}

// ------------------------------------------------------------------ Settings

@Composable
fun SettingsScreen(vm: MainViewModel, actions: HostActions) {
    val prefs by vm.prefs.collectAsState()
    var url by remember(prefs.backendUrl) { mutableStateOf(prefs.backendUrl) }
    var token by remember(prefs.token) { mutableStateOf(prefs.token) }
    var confirmClear by remember { mutableStateOf(false) }
    var waPhone by remember { mutableStateOf("") }
    var waMessage by remember { mutableStateOf("") }
    var waTime by remember { mutableStateOf("00:00") }

    LazyColumn(
        Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { Text("Settings", color = RavanColors.Text, fontSize = 22.sp, fontWeight = FontWeight.Black) }

        item {
            RCard {
                SectionTitle("Language")
                Spacer(Modifier.height(8.dp))
                LanguageChips(prefs.language) { lang -> vm.edit { language = lang } }
                Text(
                    "Auto uses your phone's default recognizer. Replies are spoken in the language they are written in.",
                    color = RavanColors.Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp)
                )
            }
        }

        item {
            RCard {
                SwitchRow("Speak replies", "Read answers aloud", prefs.speak) { on -> vm.edit { speakReplies = on } }
                SwitchRow("Wake word: RAVAN", "Keep a visible microphone notification while listening for the wake word. Uses Android speech recognition and may need internet.", prefs.wakeWord) { on ->
                    if (on) {
                        vm.edit { wakeWordEnabled = true }
                        actions.setWakeWord(true)
                    } else {
                        vm.edit { wakeWordEnabled = false }
                        actions.setWakeWord(false)
                    }
                }
                SwitchRow("Remember conversation", "Sends the last few messages with each question. Turn off to send none.", prefs.memory) { on ->
                    vm.edit { memoryEnabled = on }
                }
                Spacer(Modifier.height(6.dp))
                GhostButton("Delete chat history") { confirmClear = true }
            }
        }

        item {
            RCard {
                SectionTitle("AI backend (HTTPS only)")
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = url,
                    onValueChange = { url = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Backend URL, https://…") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                    colors = ravanFieldColors()
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = token,
                    onValueChange = { token = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("App token") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    colors = ravanFieldColors()
                )
                Spacer(Modifier.height(10.dp))
                RButton("Save backend") {
                    if (url.isNotBlank() && !url.trim().startsWith("https://")) {
                        vm.postStatus("The URL must start with https://")
                    } else {
                        vm.edit { backendUrl = url; appToken = token }
                        vm.postStatus("Backend saved.")
                    }
                }
                Text(
                    "The AI provider key stays on your server. This app only stores the URL and a token, encrypted on the phone.",
                    color = RavanColors.Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp)
                )
            }
        }

        item {
            RCard {
                SectionTitle("Scheduled WhatsApp message")
                Spacer(Modifier.height(6.dp))
                Text(
                    "RAVAN can remind you at the chosen time and open a pre-filled WhatsApp chat. WhatsApp does not provide a free supported way for this personal app to press Send automatically. You must review and send the message.",
                    color = RavanColors.Muted, fontSize = 12.sp
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = waPhone,
                    onValueChange = { waPhone = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("WhatsApp number with country code (e.g. 91...)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    colors = ravanFieldColors()
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = waMessage,
                    onValueChange = { waMessage = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Message") },
                    minLines = 2,
                    maxLines = 4,
                    colors = ravanFieldColors()
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = waTime,
                    onValueChange = { waTime = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Time, 24-hour format (HH:mm)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Ascii),
                    colors = ravanFieldColors()
                )
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    RButton("Schedule draft") { vm.scheduleWhatsAppDraft(waPhone, waMessage, waTime) }
                    GhostButton("Allow exact timing") { actions.requestExactAlarm() }
                }
                GhostButton("Allow notifications") { actions.requestNotif() }
            }
        }

        item {
            RCard {
                SectionTitle("RAVAN video editor")
                Spacer(Modifier.height(6.dp))
                Text(
                    "Open the Agent tab to select a video and edit it directly inside RAVAN: trim, rotate, resize to 720p, mute original audio and export an MP4. For advanced transitions or app-specific effects, you can later open the exported clip in an editor you already have installed.",
                    color = RavanColors.Muted, fontSize = 12.sp
                )
                Spacer(Modifier.height(10.dp))
                RButton("Choose video for RAVAN editor") { actions.pickVideo() }
            }
        }

        item {
            RCard {
                SectionTitle("Permission-based phone access")
                Spacer(Modifier.height(6.dp))
                Text(
                    "RAVAN uses Android's supported actions and only the permissions you grant. It does not get hidden, unrestricted access to every app, private message, call audio or account. This keeps your phone and accounts safer.",
                    color = RavanColors.Muted, fontSize = 12.sp
                )
            }
        }

        item {
            RCard {
                SectionTitle("File search")
                Spacer(Modifier.height(6.dp))
                Text(
                    if (prefs.folderSet) "A folder is selected. RAVAN searches only inside it." else "No folder selected. RAVAN can't see your files until you choose one.",
                    color = RavanColors.Text, fontSize = 14.sp
                )
                Spacer(Modifier.height(10.dp))
                GhostButton("Choose search folder") { actions.pickFolder() }
            }
        }

        item {
            RCard {
                SectionTitle("Privacy")
                Spacer(Modifier.height(6.dp))
                Text(
                    "RAVAN never records audio itself and never reads your messages, contacts or files unless you pick a folder. " +
                        "Chat history stays on this phone. Text you send to the AI goes to your own backend.",
                    color = RavanColors.Muted, fontSize = 13.sp
                )
            }
        }
    }

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            containerColor = RavanColors.Card,
            titleContentColor = RavanColors.Text,
            textContentColor = RavanColors.Muted,
            title = { Text("Delete chat history?") },
            text = { Text("All saved messages on this phone will be removed.") },
            confirmButton = {
                TextButton(onClick = { vm.clearMemory(); confirmClear = false }) { Text("Delete", color = RavanColors.Red) }
            },
            dismissButton = {
                TextButton(onClick = { confirmClear = false }) { Text("Cancel", color = RavanColors.Muted) }
            }
        )
    }
}
