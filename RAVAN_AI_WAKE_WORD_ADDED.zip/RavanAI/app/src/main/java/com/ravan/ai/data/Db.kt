package com.ravan.ai.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "messages")
data class MessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val role: String,            // "user", "assistant" or "action"
    val text: String,
    val ts: Long = System.currentTimeMillis()
)

@Entity(tableName = "call_logs")
data class CallLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val number: String,
    val purpose: String,
    val summary: String,
    val source: String,          // "screened" or "cloud:<id>"
    val ts: Long = System.currentTimeMillis()
)

@Dao
interface MessageDao {
    @Query("SELECT * FROM messages ORDER BY ts ASC, id ASC")
    fun observeAll(): Flow<List<MessageEntity>>

    @Query("SELECT * FROM messages ORDER BY ts DESC, id DESC LIMIT :n")
    suspend fun last(n: Int): List<MessageEntity>

    @Insert
    suspend fun insert(m: MessageEntity): Long

    @Query("DELETE FROM messages")
    suspend fun clear()
}

@Dao
interface CallDao {
    @Query("SELECT * FROM call_logs ORDER BY ts DESC, id DESC")
    fun observeAll(): Flow<List<CallLogEntity>>

    @Query("SELECT COUNT(*) FROM call_logs WHERE source = :source")
    suspend fun countBySource(source: String): Int

    @Insert
    suspend fun insert(c: CallLogEntity): Long

    @Query("DELETE FROM call_logs")
    suspend fun clear()
}

@Database(entities = [MessageEntity::class, CallLogEntity::class], version = 1, exportSchema = false)
abstract class RavanDb : RoomDatabase() {
    abstract fun messages(): MessageDao
    abstract fun calls(): CallDao

    companion object {
        @Volatile
        private var instance: RavanDb? = null

        fun get(context: Context): RavanDb =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    RavanDb::class.java,
                    "ravan.db"
                ).build().also { instance = it }
            }
    }
}
