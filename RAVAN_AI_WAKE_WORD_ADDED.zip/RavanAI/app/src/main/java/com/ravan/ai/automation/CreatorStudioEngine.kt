package com.ravan.ai.automation

import android.content.ContentValues
import android.content.Context
import android.graphics.Typeface
import android.net.Uri
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.text.SpannableString
import android.text.style.BackgroundColorSpan
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.Brightness
import androidx.media3.effect.Contrast
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.Presentation
import androidx.media3.effect.RgbFilter
import androidx.media3.effect.StaticOverlaySettings
import androidx.media3.effect.TextOverlay
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import java.io.File
import java.io.FileInputStream
import java.util.concurrent.Executors

/**
 * Free-first, on-device creator pipeline.
 * - Sequentially combines selected videos and still images.
 * - Turns still images into timed video scenes (slideshow/story video).
 * - Can mix a looping background music/audio file.
 * - Adds a static title overlay, simple color presets and 16:9 / 9:16 output.
 *
 * This is a real local render/export path. It is not a generative text-to-video model,
 * and Media3 Composition currently does not support clip crossfades.
 */
class CreatorStudioEngine(private val context: Context) {
    private val mainHandler = Handler(Looper.getMainLooper())

    @OptIn(UnstableApi::class)
    fun export(
        mediaUris: List<Uri>,
        musicUri: Uri?,
        titleOverlay: String,
        filterName: String,
        format: String,
        imageDurationMs: Long,
        muteOriginalAudio: Boolean,
        callback: (Result<Uri>) -> Unit
    ) {
        if (mediaUris.isEmpty()) {
            callback(Result.failure(IllegalArgumentException("Choose at least one photo or video.")))
            return
        }
        if (mediaUris.size > 20) {
            callback(Result.failure(IllegalArgumentException("Choose up to 20 clips/photos per project.")))
            return
        }

        val outputFile = File(context.cacheDir, "ravan_creator_${System.currentTimeMillis()}.mp4")
        try {
            val editedItems = mediaUris.mapIndexed { index, uri ->
                val mime = context.contentResolver.getType(uri).orEmpty()
                val isImage = mime.startsWith("image/") || (!mime.startsWith("video/") && looksLikeImage(uri))
                val builder = MediaItem.Builder().setUri(uri)
                if (isImage) builder.setImageDurationMs(imageDurationMs.coerceIn(2_000L, 12_000L))

                val effects = mutableListOf<androidx.media3.common.Effect>()
                when (filterName.uppercase()) {
                    "BLACK & WHITE", "GRAYSCALE", "B&W" -> effects += RgbFilter.createGrayscaleFilter()
                    "INVERT" -> effects += RgbFilter.createInvertedFilter()
                    "BRIGHT" -> effects += Brightness(0.08f)
                    "CINEMATIC" -> {
                        effects += Contrast(1.12f)
                        effects += Brightness(-0.025f)
                    }
                }
                if (format.equals("SHORTS", ignoreCase = true)) {
                    effects += Presentation.createForWidthAndHeight(
                        720, 1280, Presentation.LAYOUT_SCALE_TO_FIT
                    )
                } else {
                    effects += Presentation.createForWidthAndHeight(
                        1280, 720, Presentation.LAYOUT_SCALE_TO_FIT
                    )
                }
                // Create an overlay instance per clip so each Media3 item owns its effect instance.
                buildTitleOverlay(titleOverlay)?.let(effects::add)

                EditedMediaItem.Builder(builder.build())
                    .setRemoveAudio(muteOriginalAudio)
                    .setEffects(Effects(emptyList(), effects))
                    .build()
            }

            val videoSequence = EditedMediaItemSequence.withAudioAndVideoFrom(editedItems)
            val sequences = mutableListOf(videoSequence)
            if (musicUri != null) {
                val backgroundAudio = EditedMediaItem.Builder(MediaItem.fromUri(musicUri)).build()
                val audioSequence = EditedMediaItemSequence.withAudioFrom(listOf(backgroundAudio))
                    .buildUpon()
                    .setIsLooping(true)
                    .build()
                sequences += audioSequence
            }

            val composition = Composition.Builder(sequences).build()
            val listener = object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    val worker = Executors.newSingleThreadExecutor()
                    worker.execute {
                        val result = try {
                            saveToMovies(outputFile)
                        } catch (error: Exception) {
                            Result.failure<Uri>(error)
                        } finally {
                            outputFile.delete()
                        }
                        mainHandler.post { callback(result) }
                        worker.shutdown()
                    }
                }

                override fun onError(
                    composition: Composition,
                    exportResult: ExportResult,
                    exportException: ExportException
                ) {
                    outputFile.delete()
                    mainHandler.post { callback(Result.failure(exportException)) }
                }
            }
            val transformer = Transformer.Builder(context)
                .addListener(listener)
                .build()
            transformer.start(composition, outputFile.absolutePath)
        } catch (error: Exception) {
            outputFile.delete()
            callback(Result.failure(error))
        }
    }

    private fun looksLikeImage(uri: Uri): Boolean {
        val name = (uri.lastPathSegment ?: "").lowercase()
        return listOf(".jpg", ".jpeg", ".png", ".webp", ".heic", ".bmp").any(name::endsWith)
    }

    @OptIn(UnstableApi::class)
    private fun buildTitleOverlay(title: String): OverlayEffect? {
        val clean = title.trim().take(90)
        if (clean.isEmpty()) return null
        val text = SpannableString(clean).apply {
            setSpan(ForegroundColorSpan(android.graphics.Color.WHITE), 0, length, 0)
            setSpan(BackgroundColorSpan(0x99000000.toInt()), 0, length, 0)
            setSpan(StyleSpan(Typeface.BOLD), 0, length, 0)
        }
        val settings = StaticOverlaySettings.Builder()
            .setBackgroundFrameAnchor(0f, -0.78f)
            .setOverlayFrameAnchor(0f, -0.78f)
            .setScale(0.72f, 0.72f)
            .setAlphaScale(0.96f)
            .build()
        val overlay = TextOverlay.createStaticTextOverlay(text, settings)
        return OverlayEffect(listOf(overlay))
    }

    private fun saveToMovies(temp: File): Result<Uri> {
        if (!temp.exists() || temp.length() == 0L) {
            return Result.failure(IllegalStateException("The export is empty."))
        }
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "RAVAN_CREATOR_${System.currentTimeMillis()}.mp4")
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/RAVAN AI")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val resolver = context.contentResolver
        val target = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw IllegalStateException("Android could not create the exported video file.")
        try {
            resolver.openOutputStream(target, "w")?.use { output ->
                FileInputStream(temp).use { input -> input.copyTo(output) }
            } ?: throw IllegalStateException("Could not write the exported MP4.")
            resolver.update(target, ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }, null, null)
            return Result.success(target)
        } catch (error: Exception) {
            resolver.delete(target, null, null)
            throw error
        }
    }
}
