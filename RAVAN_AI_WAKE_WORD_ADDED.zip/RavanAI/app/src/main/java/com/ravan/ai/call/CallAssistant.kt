package com.ravan.ai.call

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.telecom.Call
import android.telecom.CallScreeningService
import android.telephony.SmsManager
import androidx.core.content.ContextCompat
import com.ravan.ai.data.CallLogEntity
import com.ravan.ai.data.RavanDb
import com.ravan.ai.data.SecureSettings
import com.ravan.ai.notify.Notifier
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * Registered as the phone's call-screening app. Android only gives such an app the caller's number
 * and lets it allow/reject/silence the call. It can NOT answer the call or hear the audio.
 * This service therefore never blocks a call: it notifies you and (optionally) sends one transparent SMS.
 */
class RavanCallScreeningService : CallScreeningService() {
    override fun onScreenCall(callDetails: Call.Details) {
        // Always let the call ring normally.
        respondToCall(callDetails, CallResponse.Builder().build())
        if (callDetails.callDirection != Call.Details.DIRECTION_INCOMING) return
        val settings = SecureSettings(applicationContext)
        if (!settings.busyMode) return
        val number = callDetails.handle?.schemeSpecificPart ?: "unknown"
        CallAssistant.onIncoming(applicationContext, settings, number)
    }
}

object CallAssistant {
    /** The exact greeting requested. Used by the cloud call flow (backend) and the in-app preview. */
    const val GREETING =
        "Hello, मी RAVAN AI बोलत आहे. करण सध्या व्यस्त आहेत. आपण कोणत्या कामासाठी फोन केला आहे?"

    private const val SMS_COOLDOWN_MS = 30 * 60 * 1000L
    private val numberRe = Regex("^\\+?[0-9]{6,15}$")

    fun onIncoming(ctx: Context, settings: SecureSettings, number: String) {
        val smsSent = settings.autoSms && trySms(ctx, settings, number)
        val note = if (smsSent) "Auto-reply SMS sent (it says an AI assistant is relaying messages)."
        else "No auto-reply sent."
        Notifier.notify(ctx, Notifier.CH_CALLS, "Call while busy", "From $number. $note")
        CoroutineScope(Dispatchers.IO).launch {
            RavanDb.get(ctx).calls().insert(
                CallLogEntity(
                    number = number,
                    purpose = "Unknown (call not answered by RAVAN)",
                    summary = note,
                    source = "screened"
                )
            )
        }
    }

    private fun smsText(settings: SecureSettings): String {
        val base = "Hello, मी RAVAN AI (AI असिस्टंट) बोलत आहे. करण सध्या व्यस्त आहेत. " +
            "कृपया आपल्या कामाचा निरोप या मेसेजला उत्तर देऊन पाठवा."
        val fwd = settings.forwardNumber
        return if (fwd.isBlank()) base else "$base किंवा AI शी बोलण्यासाठी या नंबरवर कॉल करा: $fwd"
    }

    @Suppress("DEPRECATION")
    private fun trySms(ctx: Context, settings: SecureSettings, number: String): Boolean {
        if (!numberRe.matches(number)) return false
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.SEND_SMS) !=
            PackageManager.PERMISSION_GRANTED
        ) return false
        if (System.currentTimeMillis() - settings.lastSmsAt(number) < SMS_COOLDOWN_MS) return false
        return try {
            val sm = if (Build.VERSION.SDK_INT >= 31) ctx.getSystemService(SmsManager::class.java)
            else SmsManager.getDefault()
            val parts = sm.divideMessage(smsText(settings))
            sm.sendMultipartTextMessage(number, null, parts, null, null)
            settings.markSmsSent(number)
            true
        } catch (e: Exception) {
            false
        }
    }
}
