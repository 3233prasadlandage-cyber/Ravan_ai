package com.ravan.ai.automation

/**
 * Small offline command parser (Marathi / Hindi / English keywords).
 * Used when the AI backend is not configured or not reachable.
 */
object LocalRouter {

    private fun norm(s: String): String {
        val sb = StringBuilder()
        for (c in s.lowercase()) {
            sb.append(if (c in '०'..'९') ('0' + (c - '०')) else c)
        }
        return sb.toString()
    }

    private fun has(t: String, vararg words: String): Boolean = words.any { t.contains(it) }

    private val stop = setOf(
        "open", "launch", "start", "play", "search", "on", "in", "the", "a", "please", "app", "file", "find",
        "youtube", "यूट्यूब", "युट्यूब", "उघड", "उघडा", "खोल", "खोलो", "चालव", "लाव", "कर", "करा",
        "पर", "वर", "मध्ये", "मधे", "शोध", "शोधा", "दाखव", "दाखवा", "कृपया", "फाईल", "फाइल",
        "ढूंढ", "ढूंढो", "सुरू", "चालू", "ऍप", "अॅप", "ॲप", "install", "download", "डाउनलोड", "डाऊनलोड", "इन्स्टॉल", "इंस्टॉल", "app"
    )

    private fun cleanQuery(t: String): String =
        t.split(Regex("\\s+")).filter { it.isNotBlank() && it !in stop }.joinToString(" ")

    fun parse(raw: String): Action? {
        val t = norm(raw)
        val explicitUrl = Regex("https?://[^\\s]+", RegexOption.IGNORE_CASE).find(raw)?.value?.trimEnd('.', ',', ')', ']', '}', '!', '?')
        if (explicitUrl != null) return Action("open_url", mapOf("url" to explicitUrl))
        return when {
            (t.startsWith("install ") || t.startsWith("download ") || t.startsWith("find app ") || t.startsWith("search app ") ||
                (has(t, "app", "अॅप", "ॲप", "ऍप") && has(t, "install", "download", "डाउनलोड", "डाऊनलोड", "इन्स्टॉल", "इंस्टॉल"))) -> {
                val name = cleanQuery(t)
                if (name.isBlank()) null else Action("find_app", mapOf("name" to name))
            }
            has(t, "camera", "कॅमेरा", "कैमरा", "कॅमेर") -> Action("camera")
            has(t, "alarm", "अलार्म", "गजर") -> {
                val clock = parseClock(t)
                if (clock == null) Action("show_alarms")
                else Action(
                    "alarm",
                    mapOf("hour" to clock.first.toString(), "minute" to clock.second.toString(), "label" to "RAVAN")
                )
            }
            has(t, "remind", "आठवण", "याद दिला", "रिमाइंड") -> {
                val minutes = parseMinutes(t)
                if (minutes == null) null
                else Action("reminder", mapOf("minutes" to minutes.toString(), "text" to raw.trim()))
            }
            has(t, "youtube", "यूट्यूब", "युट्यूब") -> Action("youtube", mapOf("query" to cleanQuery(t)))
            has(t, "wifi", "wi-fi", "वायफाय", "वाय-फाय", "वाय फाय") -> Action("settings", mapOf("screen" to "wifi"))
            has(t, "bluetooth", "ब्लूटूथ", "ब्लुटूथ") -> Action("settings", mapOf("screen" to "bluetooth"))
            has(t, "brightness", "display", "ब्राइटनेस", "डिस्प्ले") -> Action("settings", mapOf("screen" to "display"))
            has(t, "volume", "sound", "आवाज", "साउंड", "व्हॉल्यूम") -> Action("settings", mapOf("screen" to "sound"))
            has(t, "battery", "बॅटरी", "बैटरी") -> Action("settings", mapOf("screen" to "battery"))
            has(t, "location", "लोकेशन") -> Action("settings", mapOf("screen" to "location"))
            has(t, "settings", "सेटिंग") -> Action("settings", mapOf("screen" to "main"))
            has(t, "find file", "search file", "open file", "फाईल", "फाइल") ->
                Action("open_file", mapOf("query" to cleanQuery(t)))
            has(t, "open ", "launch ", "उघड", "खोल", "सुरू कर", "चालू कर") -> {
                val name = cleanQuery(t)
                if (name.isBlank()) null else Action("open_app", mapOf("name" to name))
            }
            else -> null
        }
    }

    private val clockRe = Regex("(\\d{1,2})(?::(\\d{2}))?")
    private val pmRe = Regex("(?<![a-z])pm(?![a-z])")
    private val amRe = Regex("(?<![a-z])am(?![a-z])")

    /** Returns hour (0-23) and minute, or null when no time is present. */
    fun parseClock(t: String): Pair<Int, Int>? {
        val m = clockRe.find(t) ?: return null
        var h = m.groupValues[1].toInt()
        val min = m.groupValues[2].ifEmpty { "0" }.toInt()
        if (h > 23 || min > 59) return null
        val pm = pmRe.containsMatchIn(t) ||
            has(t, "संध्याकाळ", "शाम", "रात्री", "रात", "दुपार", "दोपहर", "evening", "night", "afternoon")
        val am = amRe.containsMatchIn(t) || has(t, "सकाळ", "सुबह", "morning")
        if (pm && h < 12) h += 12
        if (am && !pm && h == 12) h = 0
        return Pair(h, min)
    }

    private val minutesRe = Regex(
        "(\\d+)\\s*(minutes?|mins?|min|मिनिट\\S*|मिनट\\S*|hours?|hrs?|तास\\S*|घंट\\S*)",
        RegexOption.IGNORE_CASE
    )

    /** "in 10 minutes", "२ तासांनी" -> minutes from now. */
    fun parseMinutes(t: String): Long? {
        val m = minutesRe.find(t) ?: return null
        val n = m.groupValues[1].toLongOrNull() ?: return null
        val unit = m.groupValues[2].lowercase()
        val isHours = unit.startsWith("h") || unit.startsWith("त") || unit.startsWith("घ")
        return if (isHours) n * 60 else n
    }
}
