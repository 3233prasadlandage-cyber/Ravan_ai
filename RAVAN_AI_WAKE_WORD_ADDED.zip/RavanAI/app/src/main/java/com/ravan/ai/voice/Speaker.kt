package com.ravan.ai.voice

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

/** Text-to-speech wrapper. Reports whether it is currently speaking so the UI can show a Stop button. */
class Speaker(context: Context) {
    private val _speaking = MutableStateFlow(false)
    val speaking: StateFlow<Boolean> = _speaking.asStateFlow()

    private var ready = false
    private val tts: TextToSpeech = TextToSpeech(context.applicationContext) { status ->
        ready = status == TextToSpeech.SUCCESS
    }

    init {
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) { _speaking.value = true }
            override fun onDone(utteranceId: String?) { _speaking.value = false }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) { _speaking.value = false }
        })
    }

    /** Returns the language tag actually used, or null if no suitable voice is installed. */
    fun speak(text: String, tag: String): String? {
        if (!ready || text.isBlank()) return null
        val candidates = when (tag) {
            "mr-IN" -> listOf("mr-IN", "hi-IN")
            "hi-IN" -> listOf("hi-IN")
            else -> listOf("en-IN", "en-US")
        }
        for (c in candidates) {
            val r = tts.setLanguage(Locale.forLanguageTag(c))
            if (r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED) {
                tts.speak(text.take(3500), TextToSpeech.QUEUE_FLUSH, null, "ravan-utterance")
                return c
            }
        }
        return null
    }

    fun stop() {
        tts.stop()
        _speaking.value = false
    }

    fun shutdown() {
        tts.stop()
        tts.shutdown()
    }
}
