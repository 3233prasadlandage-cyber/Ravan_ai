package com.ravan.ai.voice

object Lang {
    val options = listOf(
        "auto" to "Auto",
        "mr-IN" to "मराठी",
        "hi-IN" to "हिन्दी",
        "en-IN" to "English"
    )

    /** Picks a speaking language from the script/wording of a reply. */
    fun detect(text: String): String {
        var letters = 0
        var devanagari = 0
        for (c in text) {
            if (c.isLetter()) {
                letters++
                if (c in '\u0900'..'\u097F') devanagari++
            }
        }
        if (letters == 0 || devanagari * 3 < letters) return "en-IN"
        val marathi = listOf("आहे", "आहेत", "नाही", "करा", "तुम्ही", "काय", "होते", "आणि")
            .count { text.contains(it) }
        val hindi = listOf("है", "हैं", "नहीं", "क्या", "आप", "मैं", "और", "कीजिए", "रहा", "रही")
            .count { text.contains(it) }
        return if (hindi > marathi) "hi-IN" else "mr-IN"
    }
}
