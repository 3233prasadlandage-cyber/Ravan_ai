package com.ravan.ai

import android.app.Application
import com.ravan.ai.notify.Notifier

class RavanApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Notifier.createChannels(this)
    }
}
