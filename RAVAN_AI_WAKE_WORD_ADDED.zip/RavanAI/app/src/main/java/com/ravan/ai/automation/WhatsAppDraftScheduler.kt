package com.ravan.ai.automation

import android.app.AlarmManager
import android.content.BroadcastReceiver
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import android.Manifest
import android.content.pm.PackageManager
import com.ravan.ai.R
import java.util.Calendar

/**
 * Schedules a reminder that opens a pre-filled WhatsApp chat when the user taps it.
 * It intentionally does NOT press WhatsApp's Send button or send a message silently.
 */
object WhatsAppDraftScheduler {
    private const val PREFS = "ravan_whatsapp_draft"
    private const val KEY_AT = "at"
    private const val KEY_PHONE = "phone"
    private const val KEY_MESSAGE = "message"
    private const val REQUEST_CODE = 7401
    private const val NOTIFICATION_ID = 7401

    data class ScheduleResult(val ok: Boolean, val message: String, val atMillis: Long = 0L)

    fun hasExactAlarmAccess(context: Context): Boolean {
        val manager = context.getSystemService(AlarmManager::class.java)
        return Build.VERSION.SDK_INT < 31 || manager.canScheduleExactAlarms()
    }

    fun schedule(context: Context, rawPhone: String, message: String, time: String): ScheduleResult {
        val phone = rawPhone.filter { it.isDigit() }
        if (phone.length !in 8..15) {
            return ScheduleResult(false, "Enter a valid phone number with country code, e.g. 91XXXXXXXXXX.")
        }
        if (message.isBlank()) return ScheduleResult(false, "Enter the WhatsApp message first.")
        if (message.length > 1500) return ScheduleResult(false, "Keep the message under 1500 characters.")
        val parts = time.trim().split(":")
        if (parts.size != 2) return ScheduleResult(false, "Enter time in 24-hour format, e.g. 00:00 or 21:30.")
        val hour = parts[0].toIntOrNull()
        val minute = parts[1].toIntOrNull()
        if (hour == null || minute == null || hour !in 0..23 || minute !in 0..59) {
            return ScheduleResult(false, "Enter a valid time in HH:mm format.")
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            return ScheduleResult(false, "Allow RAVAN notifications first so it can alert you at the scheduled time.")
        }
        if (!hasExactAlarmAccess(context)) {
            return ScheduleResult(false, "Allow 'Alarms & reminders' for RAVAN in Android Settings, then schedule again.")
        }

        val calendar = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
        }
        val at = calendar.timeInMillis
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        prefs.edit().putLong(KEY_AT, at).putString(KEY_PHONE, phone).putString(KEY_MESSAGE, message.trim()).apply()
        try {
            setAlarm(context, phone, message.trim(), at)
        } catch (security: SecurityException) {
            prefs.edit().clear().apply()
            return ScheduleResult(false, "Android denied exact-alarm access. Allow Alarms & reminders for RAVAN, then try again.")
        } catch (error: Exception) {
            prefs.edit().clear().apply()
            return ScheduleResult(false, "Could not schedule the reminder: ${error.localizedMessage ?: "Unknown error"}")
        }
        return ScheduleResult(true, "WhatsApp draft reminder scheduled for ${String.format("%02d:%02d", hour, minute)}. At that time, tap the notification, review the draft, and tap Send in WhatsApp.", at)
    }

    private fun setAlarm(context: Context, phone: String, message: String, at: Long) {
        val intent = Intent(context, WhatsAppDraftAlarmReceiver::class.java)
            .putExtra(KEY_PHONE, phone)
            .putExtra(KEY_MESSAGE, message)
            .putExtra(KEY_AT, at)
        val pending = PendingIntent.getBroadcast(
            context, REQUEST_CODE, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        context.getSystemService(AlarmManager::class.java)
            .setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pending)
    }

    fun rescheduleAfterBoot(context: Context) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val at = prefs.getLong(KEY_AT, 0L)
        val phone = prefs.getString(KEY_PHONE, null) ?: return
        val message = prefs.getString(KEY_MESSAGE, null) ?: return
        if (at > System.currentTimeMillis() && hasExactAlarmAccess(context)) {
            setAlarm(context, phone, message, at)
        } else if (at > 0L && at <= System.currentTimeMillis()) {
            // The phone may have been off at the scheduled time; surface a missed draft reminder.
            showNotification(context, phone, message, at)
        }
    }

    internal fun showNotification(context: Context, phone: String, message: String, at: Long) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (prefs.getLong(KEY_AT, -1L) == at) prefs.edit().clear().apply()

        val chatUrl = "https://wa.me/$phone?text=${Uri.encode(message)}"
        val openChat = PendingIntent.getActivity(
            context, REQUEST_CODE,
            Intent(Intent.ACTION_VIEW, Uri.parse(chatUrl)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = NotificationCompat.Builder(context, "ravan_reminders")
            .setSmallIcon(R.drawable.ic_stat_ravan)
            .setContentTitle("RAVAN: WhatsApp message is ready")
            .setContentText("Tap to review the message. WhatsApp will not send it automatically.")
            .setStyle(NotificationCompat.BigTextStyle().bigText("To: $phone\n${message.take(220)}\n\nTap to open WhatsApp, review the draft, and press Send yourself."))
            .setContentIntent(openChat)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()
        NotificationManagerCompat.from(context).notify(NOTIFICATION_ID, notification)
    }
}

class WhatsAppDraftAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val phone = intent.getStringExtra("phone") ?: return
        val message = intent.getStringExtra("message") ?: return
        val at = intent.getLongExtra("at", 0L)
        WhatsAppDraftScheduler.showNotification(context, phone, message, at)
    }
}

class RavanBootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            WhatsAppDraftScheduler.rescheduleAfterBoot(context)
        }
    }
}
