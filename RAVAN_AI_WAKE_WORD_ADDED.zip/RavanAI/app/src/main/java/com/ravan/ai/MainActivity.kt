package com.ravan.ai

import android.Manifest
import android.app.role.RoleManager
import android.app.AlarmManager
import android.content.Intent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.net.Uri
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.core.content.ContextCompat
import androidx.core.content.ContextCompat.RECEIVER_NOT_EXPORTED
import com.ravan.ai.voice.WakeWordService
import com.ravan.ai.ui.HostActions
import com.ravan.ai.ui.RavanRoot
import com.ravan.ai.ui.RavanTheme

class MainActivity : ComponentActivity() {
    private var pendingWakeStart = false
    private var activityResumed = false
    private val wakeReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            stopService(Intent(this@MainActivity, WakeWordService::class.java))
            if (activityResumed) {
                vm.startListening()
                vm.postStatus("RAVAN detected. Listening for your command… Re-enable Wake word in Settings after this conversation.")
            }
        }
    }
    private val vm: MainViewModel by viewModels()

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { results ->
            vm.refreshPermissions()
            if (pendingWakeStart) {
                pendingWakeStart = false
                if (results[Manifest.permission.RECORD_AUDIO] == true || ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) startWakeWordService()
                else { vm.edit { wakeWordEnabled = false }; vm.postStatus("Microphone permission is required for the RAVAN wake word.") }
            }
        }

    private val roleLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            vm.refreshPermissions()
        }

    private val videoPicker =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) {
                try {
                    contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                } catch (_: Exception) {
                    // Some document providers issue a temporary URI; editing can still proceed during this session.
                }
                vm.selectVideoForEditing(uri)
            }
        }

    private val creatorMediaPicker =
        registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
            uris.forEach { uri ->
                try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
                catch (_: Exception) { /* Temporary picker permission remains valid for this session. */ }
            }
            if (uris.isNotEmpty()) vm.addCreatorAssets(uris)
        }

    private val creatorMusicPicker =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) {
                try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
                catch (_: Exception) { /* Temporary picker permission remains valid for this session. */ }
                vm.setCreatorMusic(uri)
            }
        }

    private val photoPicker =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            if (uri != null) vm.analyzePhoto(uri)
        }

    private val folderLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
            if (uri != null) {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                vm.edit { searchFolderUri = uri.toString() }
                vm.postStatus("Search folder saved.")
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val actions = HostActions(
            requestMic = { permLauncher.launch(arrayOf(Manifest.permission.RECORD_AUDIO)) },
            requestNotif = {
                if (Build.VERSION.SDK_INT >= 33) {
                    permLauncher.launch(arrayOf(Manifest.permission.POST_NOTIFICATIONS))
                } else {
                    vm.postStatus("Notifications need no permission on this Android version.")
                }
            },
            requestSms = { permLauncher.launch(arrayOf(Manifest.permission.SEND_SMS)) },
            requestScreeningRole = { requestScreeningRole() },
            pickFolder = { folderLauncher.launch(null) },
            pickVideo = { videoPicker.launch(arrayOf("video/*")) },
            pickPhoto = { photoPicker.launch("image/*") },
            pickCreatorAssets = { creatorMediaPicker.launch(arrayOf("video/*", "image/*")) },
            pickCreatorMusic = { creatorMusicPicker.launch(arrayOf("audio/*")) },
            openYoutubeStudio = { openExternal("https://studio.youtube.com/") },
            requestExactAlarm = { requestExactAlarmAccess() },
            setWakeWord = { enabled ->
                if (enabled) {
                    if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) startWakeWordService()
                    else { pendingWakeStart = true; permLauncher.launch(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS)) }
                } else { stopService(Intent(this, WakeWordService::class.java)); vm.postStatus("RAVAN wake word stopped.") }
            }
        )
        ContextCompat.registerReceiver(this, wakeReceiver, IntentFilter(WakeWordService.ACTION_WAKE), RECEIVER_NOT_EXPORTED)
        if (intent?.getBooleanExtra(EXTRA_START_VOICE, false) == true) {
            window.decorView.post { vm.startListening() }
        }
        setContent {
            RavanTheme {
                RavanRoot(vm, actions)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        vm.refreshPermissions()
        activityResumed = true
        if (!intent.getBooleanExtra(EXTRA_START_VOICE, false) && vm.prefs.value.wakeWord && ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            startWakeWordService()
        }
    }

    override fun onPause() {
        activityResumed = false
        super.onPause()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent.getBooleanExtra(EXTRA_START_VOICE, false)) vm.startListening()
    }

    override fun onDestroy() {
        try { unregisterReceiver(wakeReceiver) } catch (_: Exception) {}
        super.onDestroy()
    }

    private fun startWakeWordService() {
        try {
            ContextCompat.startForegroundService(this, Intent(this, WakeWordService::class.java))
            vm.postStatus("RAVAN wake word is on. Keep the notification visible.")
        } catch (_: Exception) {
            vm.edit { wakeWordEnabled = false }
            vm.postStatus("Could not start microphone foreground service. Check Android permissions and battery settings.")
        }
    }

    companion object { const val EXTRA_START_VOICE = "com.ravan.ai.START_VOICE" }

    private fun openExternal(url: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (_: Exception) {
            vm.postStatus("No browser is available to open this page.")
        }
    }

    private fun requestExactAlarmAccess() {
        if (Build.VERSION.SDK_INT < 31) {
            vm.postStatus("Exact alarm access is already available on this Android version.")
            return
        }
        val alarmManager = getSystemService(AlarmManager::class.java)
        if (alarmManager.canScheduleExactAlarms()) {
            vm.postStatus("Exact alarm access is already enabled.")
            return
        }
        try {
            startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName")))
        } catch (_: Exception) {
            vm.postStatus("Open Android Settings → Apps → RAVAN AI → Alarms & reminders and allow it.")
        }
    }

    private fun requestScreeningRole() {
        val rm = getSystemService(RoleManager::class.java)
        if (rm == null || !rm.isRoleAvailable(RoleManager.ROLE_CALL_SCREENING)) {
            vm.postStatus("Call screening is not available on this device.")
            return
        }
        if (rm.isRoleHeld(RoleManager.ROLE_CALL_SCREENING)) {
            vm.postStatus("Call screening is already enabled.")
            return
        }
        roleLauncher.launch(rm.createRequestRoleIntent(RoleManager.ROLE_CALL_SCREENING))
    }
}
