package com.ravan.ai.notify

import android.Manifest
import android.annotation.SuppressLint
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.ravan.ai.MainActivity
import com.ravan.ai.R

object Notifier {
    const val CH_REMINDERS = "ravan_reminders"
    const val CH_CALLS = "ravan_calls"

    fun createChannels(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH_REMINDERS, "Reminders", NotificationManager.IMPORTANCE_HIGH)
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_CALLS, "Call assistant", NotificationManager.IMPORTANCE_HIGH)
        )
    }

    /** Android 13+ needs a runtime permission; Android 11 (your phone) does not. */
    fun canNotify(ctx: Context): Boolean =
        Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) ==
            PackageManager.PERMISSION_GRANTED

    @SuppressLint("MissingPermission")
    fun notify(ctx: Context, channel: String, title: String, text: String): Boolean {
        if (!canNotify(ctx)) return false
        val open = PendingIntent.getActivity(
            ctx, 0,
            Intent(ctx, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(ctx, channel)
            .setSmallIcon(R.drawable.ic_stat_ravan)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setContentIntent(open)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()
        NotificationManagerCompat.from(ctx)
            .notify((System.currentTimeMillis() % Int.MAX_VALUE).toInt(), n)
        return true
    }

    /**
     * Schedules a reminder notification. On Android 11 an exact alarm needs no special permission.
     * On Android 12+ we use an inexact (but still idle-safe) alarm to avoid the exact-alarm permission.
     * Returns the planned trigger time in epoch millis.
     */
    fun scheduleReminder(ctx: Context, text: String, minutes: Long): Long {
        val at = System.currentTimeMillis() + minutes * 60_000L
        val am = ctx.getSystemService(AlarmManager::class.java)
        val intent = Intent(ctx, ReminderReceiver::class.java).putExtra("text", text)
        val pi = PendingIntent.getBroadcast(
            ctx,
            (at % Int.MAX_VALUE).toInt(),
            intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        if (Build.VERSION.SDK_INT < 31) {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        } else {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        }
        return at
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Notifier.notify(
            context,
            Notifier.CH_REMINDERS,
            "RAVAN reminder",
            intent.getStringExtra("text") ?: "Reminder"
        )
    }
}
