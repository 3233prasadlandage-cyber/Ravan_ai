package com.ravan.ai.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

object RavanColors {
    val Bg = Color(0xFF050505)
    val Card = Color(0xFF141414)
    val CardHi = Color(0xFF1E1E1E)
    val Border = Color(0xFF2B2B2B)
    val Red = Color(0xFFFF1E2D)
    val RedDeep = Color(0xFF7A0010)
    val Text = Color(0xFFF2F2F2)
    val Muted = Color(0xFF9B9B9B)
    val Green = Color(0xFF2ECC71)
    val Amber = Color(0xFFFFB020)
}

@Composable
fun RavanTheme(content: @Composable () -> Unit) {
    val scheme = darkColorScheme(
        primary = RavanColors.Red,
        onPrimary = Color.White,
        background = RavanColors.Bg,
        onBackground = RavanColors.Text,
        surface = RavanColors.Card,
        onSurface = RavanColors.Text,
        surfaceVariant = RavanColors.CardHi,
        onSurfaceVariant = RavanColors.Muted,
        outline = RavanColors.Border,
        secondaryContainer = RavanColors.RedDeep,
        onSecondaryContainer = Color.White,
        inverseSurface = RavanColors.CardHi,
        inverseOnSurface = RavanColors.Text
    )
    val type = Typography(
        headlineMedium = TextStyle(
            fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Black,
            fontSize = 28.sp, letterSpacing = 4.sp
        ),
        titleMedium = TextStyle(
            fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.SemiBold,
            fontSize = 16.sp, letterSpacing = 0.4.sp
        ),
        bodyMedium = TextStyle(
            fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Normal,
            fontSize = 14.sp, lineHeight = 20.sp
        ),
        labelSmall = TextStyle(
            fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Medium,
            fontSize = 11.sp, letterSpacing = 0.8.sp
        )
    )
    MaterialTheme(colorScheme = scheme, typography = type, content = content)
}
