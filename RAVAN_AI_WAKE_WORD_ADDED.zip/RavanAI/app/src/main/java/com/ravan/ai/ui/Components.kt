@file:OptIn(ExperimentalMaterial3Api::class)

package com.ravan.ai.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.animateFloat
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ravan.ai.voice.Lang
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun RavanLogo(modifier: Modifier = Modifier) {
    Row(modifier, verticalAlignment = Alignment.CenterVertically) {
        Canvas(Modifier.size(46.dp)) {
            val c = center
            val r = size.minDimension / 2f
            drawCircle(
                brush = Brush.radialGradient(
                    listOf(RavanColors.Red.copy(alpha = 0.55f), Color.Transparent),
                    center = c, radius = r
                ),
                radius = r
            )
            val hex = Path()
            for (i in 0 until 6) {
                val a = Math.toRadians(60.0 * i - 90.0)
                val x = c.x + r * 0.7f * cos(a).toFloat()
                val y = c.y + r * 0.7f * sin(a).toFloat()
                if (i == 0) hex.moveTo(x, y) else hex.lineTo(x, y)
            }
            hex.close()
            drawPath(hex, RavanColors.Red, style = Stroke(width = 3.dp.toPx()))
            drawCircle(RavanColors.Red, radius = r * 0.18f, center = c)
        }
        Spacer(Modifier.width(12.dp))
        Text(
            buildAnnotatedString {
                withStyle(SpanStyle(color = Color.White)) { append("RAVAN") }
                withStyle(SpanStyle(color = RavanColors.Red)) { append(" AI") }
            },
            style = TextStyle(
                fontSize = 26.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 5.sp,
                shadow = Shadow(RavanColors.Red.copy(alpha = 0.8f), blurRadius = 24f)
            )
        )
    }
}

@Composable
fun MicButton(listening: Boolean, onClick: () -> Unit) {
    val transition = rememberInfiniteTransition(label = "pulse")
    val phase by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1400, easing = LinearEasing), RepeatMode.Restart),
        label = "phase"
    )
    Box(contentAlignment = Alignment.Center, modifier = Modifier.size(190.dp)) {
        if (listening) {
            for (i in 0 until 2) {
                val p = (phase + i * 0.5f) % 1f
                Box(
                    Modifier
                        .size(112.dp)
                        .graphicsLayer {
                            scaleX = 1f + p * 0.65f
                            scaleY = 1f + p * 0.65f
                            alpha = (1f - p) * 0.6f
                        }
                        .border(2.dp, RavanColors.Red, CircleShape)
                )
            }
        }
        Box(
            Modifier
                .size(112.dp)
                .drawBehind {
                    drawCircle(
                        Brush.radialGradient(
                            listOf(RavanColors.Red.copy(alpha = 0.45f), Color.Transparent),
                            radius = size.minDimension * 0.9f
                        )
                    )
                }
        )
        Box(
            Modifier
                .size(96.dp)
                .clip(CircleShape)
                .background(Brush.verticalGradient(listOf(Color(0xFFFF3B47), RavanColors.RedDeep)))
                .clickable(onClick = onClick),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = if (listening) Icons.Default.Stop else Icons.Default.Mic,
                contentDescription = if (listening) "Stop listening" else "Start listening",
                tint = Color.White,
                modifier = Modifier.size(42.dp)
            )
        }
    }
}

@Composable
fun RCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        color = RavanColors.Card,
        shape = RoundedCornerShape(20.dp),
        border = BorderStroke(1.dp, RavanColors.Border)
    ) {
        Column(Modifier.padding(16.dp), content = content)
    }
}

@Composable
fun SectionTitle(text: String) {
    Text(
        text,
        color = RavanColors.Muted,
        fontSize = 12.sp,
        fontWeight = FontWeight.SemiBold,
        letterSpacing = 1.2.sp
    )
}

@Composable
fun StatusRow(ok: Boolean, text: String) {
    Row(Modifier.padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier
                .size(10.dp)
                .clip(CircleShape)
                .background(if (ok) RavanColors.Green else RavanColors.Amber)
        )
        Spacer(Modifier.width(10.dp))
        Text(text, color = RavanColors.Text, fontSize = 14.sp)
    }
}

@Composable
fun ShortcutTile(icon: ImageVector, label: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Column(
        modifier
            .clip(RoundedCornerShape(16.dp))
            .background(RavanColors.Card)
            .border(1.dp, RavanColors.Border, RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 14.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, contentDescription = label, tint = RavanColors.Red, modifier = Modifier.size(26.dp))
        Spacer(Modifier.height(6.dp))
        Text(label, color = RavanColors.Text, fontSize = 12.sp)
    }
}

@Composable
fun RButton(text: String, modifier: Modifier = Modifier, enabled: Boolean = true, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = modifier,
        enabled = enabled,
        shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = RavanColors.Red,
            contentColor = Color.White,
            disabledContainerColor = RavanColors.CardHi,
            disabledContentColor = RavanColors.Muted
        )
    ) { Text(text) }
}

@Composable
fun GhostButton(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    OutlinedButton(
        onClick = onClick,
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, RavanColors.Red),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = RavanColors.Red)
    ) { Text(text) }
}

@Composable
fun SwitchRow(title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = RavanColors.Text, fontSize = 15.sp, fontWeight = FontWeight.Medium)
            Text(subtitle, color = RavanColors.Muted, fontSize = 12.sp)
        }
        Spacer(Modifier.width(12.dp))
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = RavanColors.Red,
                uncheckedThumbColor = RavanColors.Muted,
                uncheckedTrackColor = RavanColors.CardHi,
                uncheckedBorderColor = RavanColors.Border
            )
        )
    }
}

@Composable
fun PermRow(title: String, why: String, ok: Boolean, buttonText: String, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            StatusRow(ok, title)
            Text(why, color = RavanColors.Muted, fontSize = 12.sp)
        }
        Spacer(Modifier.width(10.dp))
        if (!ok) GhostButton(buttonText, onClick = onClick)
    }
}

@Composable
fun LanguageChips(selected: String, onSelect: (String) -> Unit) {
    Row(
        Modifier.horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        for ((tag, label) in Lang.options) {
            FilterChip(
                selected = selected == tag,
                onClick = { onSelect(tag) },
                label = { Text(label) },
                colors = FilterChipDefaults.filterChipColors(
                    containerColor = RavanColors.Card,
                    labelColor = RavanColors.Muted,
                    selectedContainerColor = RavanColors.RedDeep,
                    selectedLabelColor = Color.White
                )
            )
        }
    }
}

@Composable
fun ravanFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedTextColor = RavanColors.Text,
    unfocusedTextColor = RavanColors.Text,
    focusedBorderColor = RavanColors.Red,
    unfocusedBorderColor = RavanColors.Border,
    cursorColor = RavanColors.Red,
    focusedLabelColor = RavanColors.Red,
    unfocusedLabelColor = RavanColors.Muted,
    focusedPlaceholderColor = RavanColors.Muted,
    unfocusedPlaceholderColor = RavanColors.Muted
)
