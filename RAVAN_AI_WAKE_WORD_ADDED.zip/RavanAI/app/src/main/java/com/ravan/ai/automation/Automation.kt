package com.ravan.ai.automation

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.AlarmClock
import android.provider.MediaStore
import android.provider.Settings
import androidx.documentfile.provider.DocumentFile
import com.ravan.ai.data.SecureSettings
import com.ravan.ai.notify.Notifier
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** A whitelisted Android action. This is not unrestricted device control. */
data class Action(val type: String, val args: Map<String, String> = emptyMap())

data class ActionResult(val ok: Boolean, val message: String)

/**
 * Executes actions with official Android APIs only. A result is reported as success only when
 * Android accepted the request; where the outcome cannot be verified the message says so.
 */
class Automation(private val ctx: Context, private val settings: SecureSettings) {

    /** Require a review before external communication, file opening, store hand-off or multi-step plans. */
    fun needsConfirmation(a: Action): Boolean = a.type in setOf(
        "share", "open_file", "find_app", "open_url", "schedule_whatsapp_draft"
    )

    /** These actions transfer control to another app; do not pretend later plan steps ran. */
    fun stopsPlanAfter(a: Action): Boolean = a.type in setOf(
        "camera", "youtube", "settings", "open_app", "alarm", "show_alarms",
        "share", "open_file", "find_app", "open_url"
    )

    fun describe(a: Action): String = when (a.type) {
        "share" -> "Open the Android share sheet with this text:\n\n\"${a.args["text"].orEmpty().take(300)}\""
        "open_file" -> "Search only your chosen folder for \"${a.args["query"].orEmpty()}\" and open the first match."
        "find_app" -> "Open Play Store search for \"${a.args["name"].orEmpty()}\". You must review the listing and tap Install."
        "schedule_whatsapp_draft" -> "Schedule a reminder for ${a.args["time"].orEmpty()} to open WhatsApp with a draft for ${a.args["phone"].orEmpty()}. WhatsApp will NOT send it automatically; you must review and tap Send."
        "open_url" -> "Open this website in your default browser: ${a.args["url"].orEmpty()}"
        else -> when (a.type) {
            "open_app" -> "Open ${a.args["name"].orEmpty()}"
            "youtube" -> "Search YouTube for ${a.args["query"].orEmpty()}"
            "alarm" -> "Open Clock with alarm ${a.args["hour"].orEmpty()}:${a.args["minute"].orEmpty()} (confirm in Clock)"
            "reminder" -> "Schedule a reminder: ${a.args["text"].orEmpty()}"
            "camera" -> "Open Camera"
            else -> a.type
        }
    }

    suspend fun execute(a: Action): ActionResult = try {
        dispatch(a)
    } catch (e: Exception) {
        ActionResult(false, "Action failed: ${e.message ?: e.javaClass.simpleName}")
    }

    private suspend fun dispatch(a: Action): ActionResult = when (a.type) {
        "camera" -> launch(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA), "Camera opened.")
        "youtube" -> youtube(a.args["query"].orEmpty())
        "settings" -> settingsScreen(a.args["screen"].orEmpty())
        "open_app" -> openApp(a.args["name"].orEmpty())
        "find_app" -> findAppInStore(a.args["name"].orEmpty())
        "open_url" -> openUrl(a.args["url"].orEmpty())
        "alarm" -> alarm(a.args)
        "show_alarms" -> launch(Intent(AlarmClock.ACTION_SHOW_ALARMS), "Alarm list opened in the Clock app.")
        "reminder" -> reminder(a.args)
        "open_file" -> openFile(a.args["query"].orEmpty())
        "share" -> share(a.args["text"].orEmpty())
        "schedule_whatsapp_draft" -> scheduleWhatsAppDraft(a.args)
        else -> ActionResult(false, "I don't know how to do \"${a.type}\" yet.")
    }

    private fun launch(intent: Intent, okMessage: String): ActionResult = try {
        ctx.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        ActionResult(true, okMessage)
    } catch (e: ActivityNotFoundException) {
        ActionResult(false, "No app on this phone can handle that.")
    } catch (e: SecurityException) {
        ActionResult(false, "Android blocked this: ${e.message}")
    }

    private fun youtube(query: String): ActionResult {
        val uri = if (query.isBlank()) Uri.parse("https://www.youtube.com")
        else Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(query))
        val app = Intent(Intent.ACTION_VIEW, uri).setPackage("com.google.android.youtube")
        return try {
            ctx.startActivity(app.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            ActionResult(true, if (query.isBlank()) "YouTube opened." else "YouTube opened for \"$query\".")
        } catch (e: ActivityNotFoundException) {
            launch(Intent(Intent.ACTION_VIEW, uri), "YouTube app not found, opened in the browser.")
        }
    }

    private fun settingsScreen(screen: String): ActionResult {
        val key = screen.lowercase().trim()
        if (key == "notifications") {
            val i = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                .putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName)
            return launch(i, "Notification settings opened.")
        }
        val action = when (key) {
            "wifi" -> Settings.ACTION_WIFI_SETTINGS
            "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
            "display" -> Settings.ACTION_DISPLAY_SETTINGS
            "sound" -> Settings.ACTION_SOUND_SETTINGS
            "battery" -> Settings.ACTION_BATTERY_SAVER_SETTINGS
            "location" -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
            "apps" -> Settings.ACTION_APPLICATION_SETTINGS
            "storage" -> Settings.ACTION_INTERNAL_STORAGE_SETTINGS
            "date" -> Settings.ACTION_DATE_SETTINGS
            "airplane" -> Settings.ACTION_AIRPLANE_MODE_SETTINGS
            else -> Settings.ACTION_SETTINGS
        }
        return launch(Intent(action), "Settings opened (${if (key.isEmpty()) "main" else key}).")
    }

    private val aliases = mapOf(
        "व्हॉट्सअॅप" to "whatsapp", "व्हॉट्सॲप" to "whatsapp", "क्रोम" to "chrome",
        "कॅल्क्युलेटर" to "calculator", "कॅलेंडर" to "calendar", "गॅलरी" to "gallery",
        "फोन" to "phone", "मेसेज" to "messages", "जीमेल" to "gmail",
        "मॅप" to "maps", "इंस्टाग्राम" to "instagram", "फोटो" to "photos"
    )

    private fun openApp(name: String): ActionResult {
        var q = name.lowercase().trim()
        if (q.isEmpty()) return ActionResult(false, "Which app should I open?")
        for ((k, v) in aliases) {
            if (q.contains(k)) q = v
        }
        val pm = ctx.packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launcher, 0)
        fun label(r: android.content.pm.ResolveInfo) = r.loadLabel(pm).toString().lowercase()
        val match = apps.firstOrNull { label(it) == q }
            ?: apps.firstOrNull { label(it).contains(q) }
            ?: apps.firstOrNull { label(it).length >= 4 && q.contains(label(it)) }
            ?: return ActionResult(false, "I couldn't find an app called \"$name\".")
        val intent = pm.getLaunchIntentForPackage(match.activityInfo.packageName)
            ?: return ActionResult(false, "\"${label(match)}\" can't be launched.")
        return launch(intent, "Opened ${match.loadLabel(pm)}.")
    }



    /** Open only a valid HTTP(S) URL in the user's default browser. */
    private fun openUrl(raw: String): ActionResult {
        val url = raw.trim()
        val uri = try { Uri.parse(url) } catch (_: Exception) { null }
        if (uri == null || uri.scheme !in setOf("http", "https") || uri.host.isNullOrBlank()) {
            return ActionResult(false, "Use a complete website address beginning with https:// or http://.")
        }
        return launch(Intent(Intent.ACTION_VIEW, uri), "Opened the website in your default browser. Review the page before taking any action.")
    }

    /** Search the official Play Store. The user must review the listing and tap Install. */
    private fun findAppInStore(name: String): ActionResult {
        val query = name.trim()
        if (query.isBlank()) return ActionResult(false, "Which app should I search for?")
        val market = Intent(Intent.ACTION_VIEW, Uri.parse("market://search?q=${Uri.encode(query)}&c=apps"))
        return try {
            ctx.startActivity(market.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            ActionResult(true, "Opened Play Store search for \"$query\". Review the app and tap Install yourself.")
        } catch (_: ActivityNotFoundException) {
            val web = Uri.parse("https://play.google.com/store/search?q=${Uri.encode(query)}&c=apps")
            launch(Intent(Intent.ACTION_VIEW, web), "Opened Play Store search in a browser. Review the app and install it yourself.")
        }
    }

    private fun alarm(args: Map<String, String>): ActionResult {
        val h = args["hour"]?.toIntOrNull()
        val m = args["minute"]?.toIntOrNull() ?: 0
        if (h == null || h < 0 || h > 23 || m < 0 || m > 59) {
            return ActionResult(false, "I need a valid alarm time, for example 7:30.")
        }
        val label = args["label"].orEmpty().ifBlank { "RAVAN" }
        val i = Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, h)
            .putExtra(AlarmClock.EXTRA_MINUTES, m)
            .putExtra(AlarmClock.EXTRA_MESSAGE, label)
        val t = String.format(Locale.US, "%02d:%02d", h, m)
        return launch(i, "Clock app opened with an alarm for $t. Confirm it there to save it.")
    }

    private fun reminder(args: Map<String, String>): ActionResult {
        val minutes = args["minutes"]?.toLongOrNull()
        if (minutes == null || minutes < 1L || minutes > 43200L) {
            return ActionResult(false, "Tell me when, for example \"in 10 minutes\".")
        }
        if (!Notifier.canNotify(ctx)) {
            return ActionResult(false, "Notification permission is needed for reminders. Grant it on the Home screen.")
        }
        val text = args["text"].orEmpty().ifBlank { "Reminder" }
        val at = Notifier.scheduleReminder(ctx, text, minutes)
        val t = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(at))
        return ActionResult(
            true,
            "Reminder set for about $t. On OPPO, keep battery optimisation off for RAVAN AI so it fires on time. Reminders are cleared if the phone restarts."
        )
    }

    private suspend fun openFile(query: String): ActionResult {
        val folder = settings.searchFolderUri
        if (folder.isBlank()) {
            return ActionResult(false, "Choose a search folder first (Settings → Choose search folder).")
        }
        if (query.isBlank()) return ActionResult(false, "Which file should I look for?")
        val found = withContext(Dispatchers.IO) {
            val root = DocumentFile.fromTreeUri(ctx, Uri.parse(folder))
            if (root == null || !root.canRead()) null
            else findFile(root, query.lowercase(), 0, intArrayOf(3000))
        } ?: return ActionResult(false, "No file matching \"$query\" in the chosen folder.")
        val i = Intent(Intent.ACTION_VIEW)
            .setDataAndType(found.uri, found.type ?: "*/*")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        return launch(i, "Opened ${found.name}.")
    }

    private fun findFile(dir: DocumentFile, q: String, depth: Int, budget: IntArray): DocumentFile? {
        if (depth > 5) return null
        for (f in dir.listFiles()) {
            budget[0] = budget[0] - 1
            if (budget[0] <= 0) return null
            if (f.isDirectory) {
                val hit = findFile(f, q, depth + 1, budget)
                if (hit != null) return hit
            } else if (f.name?.lowercase()?.contains(q) == true) {
                return f
            }
        }
        return null
    }

    private fun scheduleWhatsAppDraft(args: Map<String, String>): ActionResult {
        val result = WhatsAppDraftScheduler.schedule(
            ctx,
            args["phone"].orEmpty(),
            args["message"].orEmpty(),
            args["time"].orEmpty()
        )
        return ActionResult(result.ok, result.message)
    }

    private fun share(text: String): ActionResult {
        if (text.isBlank()) return ActionResult(false, "There is nothing to share.")
        val send = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text)
        return launch(Intent.createChooser(send, "Share via"), "Share sheet opened.")
    }
}
