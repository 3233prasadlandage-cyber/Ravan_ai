package com.ravan.ai

import android.Manifest
import android.app.Application
import android.app.role.RoleManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.net.Uri
import android.media.MediaMetadataRetriever
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.ravan.ai.ai.AiClient
import com.ravan.ai.ai.ChatTurn
import com.ravan.ai.ai.OfflineResponder
import com.ravan.ai.automation.Action
import com.ravan.ai.automation.Automation
import com.ravan.ai.automation.LocalRouter
import com.ravan.ai.automation.PhotoFaceAnalyzer
import com.ravan.ai.automation.WhatsAppDraftScheduler
import com.ravan.ai.automation.VideoEditorEngine
import com.ravan.ai.automation.CreatorStudioEngine
import com.ravan.ai.call.CallAssistant
import com.ravan.ai.data.CallLogEntity
import com.ravan.ai.data.MessageEntity
import com.ravan.ai.data.RavanDb
import com.ravan.ai.data.SecureSettings
import com.ravan.ai.notify.Notifier
import com.ravan.ai.voice.Lang
import com.ravan.ai.voice.Speaker
import com.ravan.ai.voice.SpeechInput
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class UiState(
    val listening: Boolean = false,
    val partial: String = "",
    val thinking: Boolean = false,
    val status: String = "",
    val pendingPlan: List<Action> = emptyList(),
    val runningPlan: Boolean = false,
    val photoAnalysis: String = "",
    val selectedVideoUri: String = "",
    val videoBusy: Boolean = false,
    val videoStatus: String = "",
    val editedVideoUri: String = "",
    val videoDurationSeconds: Double = 0.0,
    val creatorMediaUris: List<String> = emptyList(),
    val creatorMusicUri: String = "",
    val creatorBusy: Boolean = false,
    val creatorStatus: String = "",
    val creatorOutputUri: String = ""
)

data class Prefs(
    val language: String,
    val memory: Boolean,
    val speak: Boolean,
    val wakeWord: Boolean,
    val busy: Boolean,
    val autoSms: Boolean,
    val backendUrl: String,
    val token: String,
    val forward: String,
    val folderSet: Boolean
)

data class Perms(val mic: Boolean, val notif: Boolean, val sms: Boolean, val screening: Boolean)

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val ctx = app.applicationContext
    private val db = RavanDb.get(ctx)
    private val settings = SecureSettings(ctx)
    private val ai = AiClient(settings)
    private val automation = Automation(ctx, settings)
    private val videoEditor = VideoEditorEngine(ctx)
    private val creatorStudio = CreatorStudioEngine(ctx)
    private val input = SpeechInput(ctx)
    private val speaker = Speaker(ctx)

    val messages: StateFlow<List<MessageEntity>> =
        db.messages().observeAll().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val calls: StateFlow<List<CallLogEntity>> =
        db.calls().observeAll().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val speaking: StateFlow<Boolean> = speaker.speaking

    private val _ui = MutableStateFlow(UiState())
    val ui: StateFlow<UiState> = _ui.asStateFlow()
    private val _prefs = MutableStateFlow(readPrefs())
    val prefs: StateFlow<Prefs> = _prefs.asStateFlow()
    private val _perm = MutableStateFlow(readPerms())
    val perm: StateFlow<Perms> = _perm.asStateFlow()

    init {
        if (settings.backendUrl.isNotBlank()) syncCalls()
    }

    // ---------- settings / permissions ----------

    private fun readPrefs() = Prefs(
        language = settings.language,
        memory = settings.memoryEnabled,
        speak = settings.speakReplies,
        wakeWord = settings.wakeWordEnabled,
        busy = settings.busyMode,
        autoSms = settings.autoSms,
        backendUrl = settings.backendUrl,
        token = settings.appToken,
        forward = settings.forwardNumber,
        folderSet = settings.searchFolderUri.isNotBlank()
    )

    fun edit(block: SecureSettings.() -> Unit) {
        settings.block()
        _prefs.value = readPrefs()
    }

    private fun granted(p: String) =
        ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED

    private fun readPerms(): Perms {
        val rm = ctx.getSystemService(RoleManager::class.java)
        val screening = rm != null &&
            rm.isRoleAvailable(RoleManager.ROLE_CALL_SCREENING) &&
            rm.isRoleHeld(RoleManager.ROLE_CALL_SCREENING)
        return Perms(
            mic = granted(Manifest.permission.RECORD_AUDIO),
            notif = Notifier.canNotify(ctx),
            sms = granted(Manifest.permission.SEND_SMS),
            screening = screening
        )
    }

    fun refreshPermissions() {
        _perm.value = readPerms()
    }

    fun postStatus(msg: String) = _ui.update { it.copy(status = msg) }
    fun clearStatus() = _ui.update { it.copy(status = "") }

    fun clearMemory() {
        viewModelScope.launch { db.messages().clear() }
    }

    // ---------- voice ----------

    fun startListening() {
        if (!input.isAvailable()) {
            postStatus("Speech recognition is not available. Install or enable the Google app (voice typing).")
            return
        }
        speaker.stop()
        val tag = settings.language.takeIf { it != "auto" }
        input.start(
            tag,
            onState = { l -> _ui.update { it.copy(listening = l) } },
            onPartial = { p -> _ui.update { it.copy(partial = p) } },
            onResult = { r ->
                _ui.update { it.copy(partial = "") }
                submit(r)
            },
            onFail = { e -> _ui.update { it.copy(status = e, listening = false, partial = "") } }
        )
    }

    fun stopListening() = input.stop()

    fun stopSpeaking() = speaker.stop()

    /** On-device photo understanding: face count and general scene/object labels, never identity. */
    fun analyzePhoto(uri: Uri) {
        _ui.update { it.copy(photoAnalysis = "Analyzing photo on this phone…") }
        PhotoFaceAnalyzer.analyze(ctx, uri) { result ->
            _ui.update { it.copy(photoAnalysis = result) }
        }
    }

    /** Opens Play Store search; Android/Play Store still requires the user to choose and install. */
    fun searchAppInStore(name: String) {
        viewModelScope.launch {
            val result = automation.execute(Action("find_app", mapOf("name" to name)))
            postStatus(result.message)
        }
    }

    private fun speakText(text: String) {
        val wanted = Lang.detect(text)
        val used = speaker.speak(text, wanted)
        if (used == null) {
            postStatus("No text-to-speech voice is ready. Install a voice in Android Settings → Text-to-speech.")
        } else if (used != wanted) {
            postStatus("$wanted voice not installed, used $used instead.")
        }
    }

    fun previewGreeting() {
        speaker.stop()
        val used = speaker.speak(CallAssistant.GREETING, "mr-IN")
        if (used == null) postStatus("No text-to-speech voice is ready.")
        else if (used != "mr-IN") postStatus("Marathi voice not installed, used $used instead.")
    }

    // ---------- chat / AI ----------

    private suspend fun history(): List<ChatTurn> =
        if (!settings.memoryEnabled) emptyList()
        else db.messages().last(12).reversed()
            .filter { it.role == "user" || it.role == "assistant" }
            .map { ChatTurn(it.role, it.text) }

    fun submit(text: String) {
        val t = text.trim()
        if (t.isEmpty() || _ui.value.thinking) return
        viewModelScope.launch {
            val hist = history()
            db.messages().insert(MessageEntity(role = "user", text = t))
            _ui.update { it.copy(thinking = true, status = "") }
            var reply = ""
            var actions = emptyList<Action>()
            if (settings.backendUrl.isNotBlank()) {
                val r = ai.chat(hist, t, settings.language)
                if (r.isSuccess) {
                    val v = r.getOrThrow()
                    reply = v.reply
                    actions = v.actions
                } else {
                    actions = LocalRouter.parse(t)?.let(::listOf) ?: emptyList()
                    if (actions.isEmpty()) {
                        reply = OfflineResponder.reply(t) ?: ("AI सर्व्हरशी संपर्क होऊ शकला नाही (${r.exceptionOrNull()?.message}). " +
                            "मोफत ऑफलाइन मोडमध्ये मूलभूत कमांड्स आणि मर्यादित संवाद उपलब्ध आहेत: कॅमेरा, अलार्म, YouTube, सेटिंग्ज, अॅप उघडणे.")
                    }
                }
            } else {
                actions = LocalRouter.parse(t)?.let(::listOf) ?: emptyList()
                if (actions.isEmpty()) {
                    reply = OfflineResponder.reply(t) ?: ("मोफत ऑफलाइन मोड सुरू आहे. मी मर्यादित सामान्य संवाद आणि फोनवरील मूलभूत कमांड्स करू शकतो: " +
                        "कॅमेरा, अलार्म, YouTube, रिमाइंडर, सेटिंग्ज आणि अॅप उघडणे. पूर्ण मुक्त-स्वरूप AI नियोजनासाठी cloud AI सेवा लागते.")
                }
            }
            if (reply.isNotBlank()) {
                db.messages().insert(MessageEntity(role = "assistant", text = reply))
                if (settings.speakReplies) speakText(reply)
            }
            _ui.update { it.copy(thinking = false) }
            if (actions.isNotEmpty()) {
                // Any multi-step plan is shown before execution. Sensitive hand-offs always need review.
                if (actions.size > 1 || actions.any(automation::needsConfirmation)) {
                    _ui.update { it.copy(pendingPlan = actions.take(5)) }
                } else {
                    executePlan(actions, speak = reply.isBlank())
                }
            }
        }
    }

    private suspend fun runAction(a: Action, speak: Boolean) {
        val r = automation.execute(a)
        db.messages().insert(MessageEntity(role = "action", text = (if (r.ok) "✔ " else "✖ ") + r.message))
        if (speak && settings.speakReplies) speakText(r.message)
    }

    /** Execute a bounded, allow-listed plan in order. Stop immediately on failure or app hand-off. */
    private suspend fun executePlan(actions: List<Action>, speak: Boolean) {
        if (actions.isEmpty()) return
        _ui.update { it.copy(runningPlan = true) }
        var completed = 0
        for ((index, action) in actions.take(5).withIndex()) {
            val result = automation.execute(action)
            db.messages().insert(
                MessageEntity(
                    role = "action",
                    text = "${index + 1}/${actions.size}: " + (if (result.ok) "✔ " else "✖ ") + result.message
                )
            )
            if (!result.ok) break
            completed++
            if (automation.stopsPlanAfter(action)) {
                if (index < actions.lastIndex) {
                    db.messages().insert(MessageEntity(role = "action", text = "Plan paused: finish the hand-off in the opened app, then give RAVAN the next instruction."))
                }
                break
            }
        }
        _ui.update { it.copy(runningPlan = false) }
        if (speak && settings.speakReplies) {
            val summary = if (completed == actions.size) "Plan actions completed or handed off. Check the action log for each result." else "The plan stopped after $completed of ${actions.size} steps. Check the action log."
            speakText(summary)
        }
    }

    fun runShortcut(a: Action) {
        viewModelScope.launch {
            val r = automation.execute(a)
            db.messages().insert(MessageEntity(role = "action", text = (if (r.ok) "✔ " else "✖ ") + r.message))
            if (!r.ok) postStatus(r.message)
        }
    }

    fun describe(a: Action): String = automation.describe(a)

    fun describePlan(actions: List<Action>): String = buildString {
        append("RAVAN proposes these steps. Review before running:\n\n")
        actions.take(5).forEachIndexed { index, action ->
            append("${index + 1}. ${automation.describe(action)}\n")
        }
        append("\nSome steps may open another app and need you to finish there. RAVAN will stop if a step fails.")
    }

    fun confirmPending() {
        val actions = _ui.value.pendingPlan
        if (actions.isEmpty()) return
        _ui.update { it.copy(pendingPlan = emptyList()) }
        viewModelScope.launch { executePlan(actions, speak = false) }
    }

    fun cancelPending() {
        _ui.update { it.copy(pendingPlan = emptyList()) }
    }


    // ---------- scheduled messaging and media hand-off ----------

    fun scheduleWhatsAppDraft(phone: String, message: String, time: String) {
        val result = WhatsAppDraftScheduler.schedule(ctx, phone, message, time)
        postStatus(result.message)
    }

    fun selectVideoForEditing(uri: Uri) {
        _ui.update {
            it.copy(
                selectedVideoUri = uri.toString(),
                videoBusy = false,
                videoStatus = "Reading video duration…",
                editedVideoUri = "",
                videoDurationSeconds = 0.0
            )
        }
        viewModelScope.launch(Dispatchers.IO) {
            val duration = try {
                val retriever = MediaMetadataRetriever()
                try {
                    retriever.setDataSource(ctx, uri)
                    retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toDoubleOrNull()?.div(1000.0) ?: 0.0
                } finally {
                    retriever.release()
                }
            } catch (_: Exception) { 0.0 }
            withContext(Dispatchers.Main) {
                _ui.update {
                    it.copy(
                        videoDurationSeconds = duration,
                        videoStatus = if (duration > 0) "Video selected (${String.format(java.util.Locale.US, "%.1f", duration)} seconds). Set trim points and export." else "Video selected. Enter start/end times in seconds and export."
                    )
                }
            }
        }
    }

    fun exportEditedVideo(startSeconds: String, endSeconds: String, muteAudio: Boolean, rotationDegrees: Int) {
        val selected = _ui.value.selectedVideoUri
        if (selected.isBlank()) {
            postStatus("Choose a video first.")
            return
        }
        val start = startSeconds.trim().toDoubleOrNull()
        val end = endSeconds.trim().toDoubleOrNull()
        if (start == null || end == null || start < 0 || end <= start) {
            _ui.update { it.copy(videoStatus = "Enter valid start and end times in seconds; end must be greater than start.") }
            return
        }
        val duration = _ui.value.videoDurationSeconds
        if (duration > 0.0 && (start >= duration || end > duration + 0.1)) {
            _ui.update { it.copy(videoStatus = "The selected trim points must be within the video duration (${String.format(java.util.Locale.US, "%.1f", duration)} seconds).") }
            return
        }
        _ui.update { it.copy(videoBusy = true, videoStatus = "Editing and exporting on this phone…", editedVideoUri = "") }
        videoEditor.export(Uri.parse(selected), start, end, muteAudio, rotationDegrees) { result ->
            result.onSuccess { output ->
                _ui.update {
                    it.copy(
                        videoBusy = false,
                        videoStatus = "Finished. Saved to Movies/RAVAN AI.",
                        editedVideoUri = output.toString()
                    )
                }
            }.onFailure { error ->
                _ui.update {
                    it.copy(videoBusy = false, videoStatus = "Video export failed: ${error.message ?: error.javaClass.simpleName}")
                }
            }
        }
    }

    fun shareEditedVideo() {
        val value = _ui.value.editedVideoUri
        if (value.isBlank()) {
            postStatus("Export a video first.")
            return
        }
        try {
            val uri = Uri.parse(value)
            val send = Intent(Intent.ACTION_SEND)
                .setType("video/mp4")
                .putExtra(Intent.EXTRA_STREAM, uri)
                .setClipData(ClipData.newUri(ctx.contentResolver, "RAVAN edited video", uri))
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(Intent.createChooser(send, "Share RAVAN edited video").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (error: Exception) {
            postStatus("Could not share edited video: ${error.message ?: "unknown error"}")
        }
    }

    fun shareVideoToEditor(uri: Uri) {
        try {
            val send = Intent(Intent.ACTION_SEND)
                .setType("video/*")
                .putExtra(Intent.EXTRA_STREAM, uri)
                .setClipData(ClipData.newUri(ctx.contentResolver, "RAVAN video", uri))
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(Intent.createChooser(send, "Choose CapCut, VN, KineMaster or another video editor")
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            postStatus("Video shared to the editor chooser. Choose an editor and make the edits there.")
        } catch (e: Exception) {
            postStatus("Could not open a video editor: ${e.message ?: "Unknown error"}")
        }
    }

    // ---------- Creator Studio: multi-asset local editing ----------

    fun addCreatorAssets(uris: List<Uri>) {
        val current = _ui.value.creatorMediaUris
        val merged = (current + uris.map(Uri::toString)).distinct().take(20)
        _ui.update {
            it.copy(
                creatorMediaUris = merged,
                creatorStatus = if (merged.isEmpty()) "No media selected." else "${merged.size} media asset(s) ready for the timeline."
            )
        }
    }

    fun clearCreatorAssets() {
        _ui.update { it.copy(creatorMediaUris = emptyList(), creatorStatus = "Timeline cleared.") }
    }

    fun setCreatorMusic(uri: Uri?) {
        _ui.update {
            it.copy(
                creatorMusicUri = uri?.toString().orEmpty(),
                creatorStatus = if (uri == null) "Background music removed." else "Background music selected."
            )
        }
    }

    fun exportCreatorVideo(
        title: String,
        filterName: String,
        format: String,
        imageDurationSeconds: Int,
        muteOriginalAudio: Boolean
    ) {
        val current = _ui.value
        val assets = current.creatorMediaUris.map(Uri::parse)
        if (assets.isEmpty()) {
            _ui.update { it.copy(creatorStatus = "Choose at least one photo or video first.") }
            return
        }
        if (title.isBlank()) {
            _ui.update { it.copy(creatorStatus = "Enter a video title or a short overlay caption.") }
            return
        }
        _ui.update { it.copy(creatorBusy = true, creatorStatus = "Building the timeline and exporting on this phone…", creatorOutputUri = "") }
        creatorStudio.export(
            mediaUris = assets,
            musicUri = current.creatorMusicUri.takeIf(String::isNotBlank)?.let(Uri::parse),
            titleOverlay = title.trim(),
            filterName = filterName,
            format = format,
            imageDurationMs = imageDurationSeconds.coerceIn(2, 12) * 1000L,
            muteOriginalAudio = muteOriginalAudio
        ) { result ->
            result.onSuccess { output ->
                _ui.update {
                    it.copy(
                        creatorBusy = false,
                        creatorStatus = "Export complete. Saved in Movies/RAVAN AI.",
                        creatorOutputUri = output.toString()
                    )
                }
            }.onFailure { error ->
                _ui.update {
                    it.copy(creatorBusy = false, creatorStatus = "Creator export failed: ${error.localizedMessage ?: error.javaClass.simpleName}")
                }
            }
        }
    }

    fun copyYouTubeUploadDetails(title: String, description: String, tags: String) {
        val text = buildString {
            append("Title: ").append(title.trim()).append("\n\n")
            append("Description: ").append(description.trim()).append("\n\n")
            append("Tags: ").append(tags.trim())
        }
        if (title.isBlank() || description.isBlank()) {
            postStatus("Enter at least a video title and description before copying upload details.")
            return
        }
        val clipboard = ctx.getSystemService(ClipboardManager::class.java)
        if (clipboard == null) {
            postStatus("Android clipboard is not available.")
            return
        }
        clipboard.setPrimaryClip(ClipData.newPlainText("RAVAN YouTube upload details", text))
        postStatus("YouTube title, description and tags copied. Paste them in YouTube Studio and review before publishing.")
    }

    fun shareCreatorVideo() {
        val output = _ui.value.creatorOutputUri
        if (output.isBlank()) {
            postStatus("Create a video first.")
            return
        }
        try {
            val uri = Uri.parse(output)
            val send = Intent(Intent.ACTION_SEND)
                .setType("video/mp4")
                .putExtra(Intent.EXTRA_STREAM, uri)
                .setClipData(ClipData.newUri(ctx.contentResolver, "RAVAN creator video", uri))
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(Intent.createChooser(send, "Share your RAVAN video").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (error: Exception) {
            postStatus("Could not share video: ${error.localizedMessage ?: "unknown error"}")
        }
    }

    // ---------- call summaries from the cloud call flow ----------

    fun syncCalls() {
        viewModelScope.launch {
            if (settings.backendUrl.isBlank()) {
                postStatus("Set the backend URL in Settings first.")
                return@launch
            }
            val r = ai.fetchCalls()
            if (r.isSuccess) {
                var added = 0
                for (c in r.getOrThrow()) {
                    val src = "cloud:" + c.id
                    if (db.calls().countBySource(src) == 0) {
                        db.calls().insert(
                            CallLogEntity(
                                number = c.number, purpose = c.purpose, summary = c.summary,
                                source = src, ts = c.ts
                            )
                        )
                        added++
                    }
                }
                postStatus("Call summaries synced: $added new.")
            } else {
                postStatus("Could not sync call summaries: ${r.exceptionOrNull()?.message}")
            }
        }
    }

    override fun onCleared() {
        input.destroy()
        speaker.shutdown()
        super.onCleared()
    }
}
