package com.ravan.ai.ai

/**
 * Tiny deterministic on-device fallback. This is intentionally NOT described as a full LLM.
 * It provides basic conversation/help replies when no paid cloud AI backend is configured.
 */
object OfflineResponder {
    fun reply(raw: String): String? {
        val t = raw.trim().lowercase()
        if (t.isBlank()) return null
        val mr = listOf("नमस्कार", "कसा आहेस", "कशी आहेस", "तू कोण", "तुझे नाव", "मदत", "धन्यवाद", "थँक")
        val hi = listOf("नमस्ते", "कैसे हो", "तुम कौन", "तुम्हारा नाम", "मदद", "धन्यवाद", "शुक्रिया")
        val en = listOf("hello", "hi", "how are you", "who are you", "your name", "help", "thank")
        return when {
            mr.any { t.contains(it) } -> when {
                t.contains("तू कोण") || t.contains("तुझे नाव") -> "मी RAVAN AI आहे. मी तुमच्या फोनवरील काही कामे करू शकतो आणि आवाजात उत्तर देऊ शकतो."
                t.contains("मदत") -> "मी कॅमेरा उघडणे, YouTube शोध, अलार्म, रिमाइंडर आणि फोन सेटिंग्ज उघडण्यात मदत करू शकतो."
                t.contains("धन्यवाद") || t.contains("थँक") -> "स्वागत आहे! अजून काही मदत हवी आहे का?"
                else -> "नमस्कार! मी RAVAN AI आहे. तुम्हाला काय मदत हवी आहे?"
            }
            hi.any { t.contains(it) } -> when {
                t.contains("कौन") || t.contains("नाम") -> "मैं RAVAN AI हूँ। मैं आपके फोन के कुछ कामों में मदद कर सकता हूँ।"
                t.contains("मदद") -> "मैं कैमरा, YouTube खोज, अलार्म, रिमाइंडर और फोन सेटिंग्स खोलने में मदद कर सकता हूँ।"
                t.contains("धन्यवाद") || t.contains("शुक्रिया") -> "आपका स्वागत है! और कुछ मदद चाहिए?"
                else -> "नमस्ते! मैं RAVAN AI हूँ। बताइए, मैं क्या मदद करूँ?"
            }
            en.any { t.contains(it) } -> when {
                t.contains("who are") || t.contains("your name") -> "I am RAVAN AI. I can help with basic phone actions and voice replies."
                t.contains("help") -> "I can open the camera, search YouTube, set alarms and reminders, and open phone settings."
                t.contains("thank") -> "You're welcome! What else can I help with?"
                else -> "Hello! I am RAVAN AI. What can I help you with?"
            }
            else -> null
        }
    }
}
