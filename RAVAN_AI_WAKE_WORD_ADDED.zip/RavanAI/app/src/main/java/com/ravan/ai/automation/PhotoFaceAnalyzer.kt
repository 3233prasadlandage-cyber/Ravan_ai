package com.ravan.ai.automation

import android.content.Context
import android.net.Uri
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import com.google.mlkit.vision.label.ImageLabeling
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions
import java.util.Locale

/**
 * On-device photo understanding. Reports face count and general visible object/scene labels.
 * It intentionally does not identify a real person's identity, infer a name, or compare faces.
 * The chosen image is processed locally and is not uploaded by this analyzer.
 */
object PhotoFaceAnalyzer {
    fun analyze(context: Context, uri: Uri, onResult: (String) -> Unit) {
        val faceDetector = FaceDetection.getClient(
            FaceDetectorOptions.Builder()
                .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_ACCURATE)
                .setLandmarkMode(FaceDetectorOptions.LANDMARK_MODE_NONE)
                .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_NONE)
                .build()
        )
        val labeler = ImageLabeling.getClient(ImageLabelerOptions.DEFAULT_OPTIONS)

        try {
            val image = InputImage.fromFilePath(context, uri)
            faceDetector.process(image)
                .addOnSuccessListener { faces ->
                    labeler.process(image)
                        .addOnSuccessListener { labels ->
                            val topLabels = labels
                                .sortedByDescending { it.confidence }
                                .take(8)
                                .joinToString(", ") {
                                    "${it.text} (${String.format(Locale.US, "%.0f", it.confidence * 100)}%)"
                                }
                            val faceText = when (faces.size) {
                                0 -> "No clear face detected"
                                1 -> "1 face detected"
                                else -> "${faces.size} faces detected"
                            }
                            val sceneText = if (topLabels.isBlank()) "No confident object labels found" else topLabels
                            onResult("$faceText. Scene/object labels: $sceneText. Processed on this phone. RAVAN does not identify who the people are.")
                        }
                        .addOnFailureListener { error ->
                            onResult("Detected ${faces.size} face(s), but image labels failed: ${error.localizedMessage ?: "unknown error"}. Photo stayed on this phone.")
                        }
                        .addOnCompleteListener { labeler.close(); faceDetector.close() }
                }
                .addOnFailureListener { error ->
                    onResult("Photo analysis failed: ${error.localizedMessage ?: "unsupported or unclear image"}")
                }
                .addOnCompleteListener { task ->
                    if (task.isFailure) {
                        labeler.close()
                        faceDetector.close()
                    }
                }
        } catch (error: Exception) {
            labeler.close()
            faceDetector.close()
            onResult("Could not open this photo: ${error.localizedMessage ?: "unknown error"}")
        }
    }
}
