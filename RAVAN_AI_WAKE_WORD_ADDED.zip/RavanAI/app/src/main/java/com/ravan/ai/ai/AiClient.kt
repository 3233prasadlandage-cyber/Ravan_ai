package com.ravan.ai.ai

import com.ravan.ai.automation.Action
import com.ravan.ai.data.SecureSettings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.time.ZonedDateTime
import java.util.concurrent.TimeUnit

data class ChatTurn(val role: String, val text: String)
data class AiReply(val reply: String, val actions: List<Action>)
data class RemoteCall(val id: String, val number: String, val purpose: String, val summary: String, val ts: Long)

/** Talks only to YOUR backend over HTTPS. The AI provider key never exists in this app. */
class AiClient(private val settings: SecureSettings) {
    private val http = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()
    private val jsonType = "application/json; charset=utf-8".toMediaType()

    private fun base(): String {
        val u = settings.backendUrl
        require(u.startsWith("https://")) { "Backend URL must start with https://" }
        return u
    }

    suspend fun chat(history: List<ChatTurn>, text: String, language: String): Result<AiReply> =
        withContext(Dispatchers.IO) {
            runCatching {
                val msgs = JSONArray()
                history.forEach { msgs.put(JSONObject().put("role", it.role).put("content", it.text)) }
                msgs.put(JSONObject().put("role", "user").put("content", text))
                val body = JSONObject()
                    .put("messages", msgs)
                    .put("language", language)
                    .put("now", ZonedDateTime.now().toString())
                    .toString()
                    .toRequestBody(jsonType)
                val req = Request.Builder()
                    .url(base() + "/chat")
                    .header("Authorization", "Bearer " + settings.appToken)
                    .post(body)
                    .build()
                http.newCall(req).execute().use { resp ->
                    val s = resp.body?.string().orEmpty()
                    if (!resp.isSuccessful) error("server replied ${resp.code}")
                    val o = JSONObject(s)
                    val actions = mutableListOf<Action>()
                    val actionArray = o.optJSONArray("actions")
                    if (actionArray != null) {
                        for (i in 0 until minOf(actionArray.length(), 5)) {
                            val actionJson = actionArray.optJSONObject(i) ?: continue
                            parseAction(actionJson)?.let(actions::add)
                        }
                    }
                    // Compatibility with earlier backend builds that returned one `action`.
                    if (actions.isEmpty()) o.optJSONObject("action")?.let { parseAction(it)?.let(actions::add) }
                    AiReply(o.optString("reply", ""), actions.toList())
                }
            }
        }

    suspend fun fetchCalls(): Result<List<RemoteCall>> = withContext(Dispatchers.IO) {
        runCatching {
            val req = Request.Builder()
                .url(base() + "/calls")
                .header("Authorization", "Bearer " + settings.appToken)
                .get()
                .build()
            http.newCall(req).execute().use { resp ->
                val s = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) error("server replied ${resp.code}")
                val arr = JSONObject(s).optJSONArray("calls") ?: JSONArray()
                val out = mutableListOf<RemoteCall>()
                for (i in 0 until arr.length()) {
                    val c = arr.getJSONObject(i)
                    out.add(
                        RemoteCall(
                            c.optString("id"), c.optString("number"), c.optString("purpose"),
                            c.optString("summary"), c.optLong("ts", System.currentTimeMillis())
                        )
                    )
                }
                out.toList()
            }
        }
    }

    private fun parseAction(o: JSONObject): Action? {
        val type = o.optString("type")
        if (type.isBlank()) return null
        val args = o.optJSONObject("args")
        val map = mutableMapOf<String, String>()
        if (args != null) {
            val keys = args.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                map[k] = args.optString(k)
            }
        }
        return Action(type, map)
    }
}
