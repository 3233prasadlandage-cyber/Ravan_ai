package com.ravan.ai.voice

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.os.Bundle
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.ravan.ai.MainActivity
import com.ravan.ai.R
import java.util.Locale

/**
 * Opt-in foreground wake-word prototype. Android's installed speech recognition provider
 * performs recognition; this is not an offline acoustic keyword model. Provider/OEM policies
 * may stop long-running recognition, so the service restarts short recognition sessions.
 */
class WakeWordService : Service() {
    private val handler = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var running = false
    private var triggered = false

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (running) return START_STICKY
        triggered = false
        running = true
        ServiceCompat.startForeground(this, NOTIFICATION_ID, notification("Listening for ‘RAVAN’ — tap notification to open"), ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        startRecognition()
        return START_STICKY
    }

    private fun startRecognition() {
        if (!running || triggered) return
        try {
            recognizer?.destroy()
            val r = SpeechRecognizer.createSpeechRecognizer(this)
            recognizer = r
            r.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onError(error: Int) { scheduleRestart() }
                override fun onResults(results: Bundle?) {
                    val phrases = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
                    if (phrases.any { isWakePhrase(it) }) onWakeWord() else scheduleRestart()
                }
                override fun onPartialResults(partialResults: Bundle?) {
                    val phrases = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
                    if (phrases.any { isWakePhrase(it) }) onWakeWord()
                }
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            val speechIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN")
                .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                .putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
            r.startListening(speechIntent)
        } catch (_: Exception) {
            scheduleRestart()
        }
    }

    private fun isWakePhrase(text: String): Boolean {
        val normalized = text.lowercase(Locale.ROOT).replace(Regex("[^a-z0-9 ]"), " ").trim()
        return normalized.split(Regex("\\s+")).any { it == "ravan" }
    }

    private fun onWakeWord() {
        if (triggered) return
        triggered = true
        try { recognizer?.cancel() } catch (_: Exception) {}
        updateNotification("RAVAN detected — tap here to start talking")
        // If the app is already visible, MainActivity receives this and starts voice input.
        sendBroadcast(Intent(ACTION_WAKE).setPackage(packageName))
        // Do not open an Activity from the background. The persistent notification is the user-visible handoff.
        // Keep the foreground notification available for the user to tap; do not
        // reopen the microphone while the conversation recognizer is active.
        running = false
    }

    private fun scheduleRestart() {
        if (!running || triggered) return
        handler.removeCallbacksAndMessages(null)
        handler.postDelayed({ startRecognition() }, 900L)
    }

    private fun notification(message: String): Notification {
        val open = Intent(this, MainActivity::class.java).putExtra(MainActivity.EXTRA_START_VOICE, true)
        val pending = PendingIntent.getActivity(this, 701, open,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_ravan)
            .setContentTitle("RAVAN AI")
            .setContentText(message)
            .setContentIntent(pending)
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun updateNotification(message: String) {
        getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, notification(message))
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "RAVAN wake word", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    override fun onDestroy() {
        running = false
        handler.removeCallbacksAndMessages(null)
        try { recognizer?.destroy() } catch (_: Exception) {}
        recognizer = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_WAKE = "com.ravan.ai.ACTION_WAKE_WORD"
        const val ACTION_STOP = "com.ravan.ai.STOP_WAKE_WORD"
        private const val CHANNEL_ID = "ravan_wake_word"
        private const val NOTIFICATION_ID = 701
    }
}
