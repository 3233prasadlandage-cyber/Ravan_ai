@file:OptIn(ExperimentalMaterial3Api::class)

package com.ravan.ai.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import com.ravan.ai.MainViewModel

/** Things only an Activity can do (permission dialogs, role request, folder picker). */
class HostActions(
    val requestMic: () -> Unit,
    val requestNotif: () -> Unit,
    val requestSms: () -> Unit,
    val requestScreeningRole: () -> Unit,
    val pickFolder: () -> Unit,
    val pickVideo: () -> Unit,
    val pickPhoto: () -> Unit,
    val pickCreatorAssets: () -> Unit,
    val pickCreatorMusic: () -> Unit,
    val openYoutubeStudio: () -> Unit,
    val requestExactAlarm: () -> Unit,
    val setWakeWord: (Boolean) -> Unit
)

@Composable
fun RavanRoot(vm: MainViewModel, actions: HostActions) {
    var tab by remember { mutableIntStateOf(0) }
    val ui by vm.ui.collectAsState()
    val snack = remember { SnackbarHostState() }
    val tabs: List<Pair<String, ImageVector>> = remember {
        listOf(
            "Home" to Icons.Default.Home,
            "Chat" to Icons.Default.ChatBubble,
            "Agent" to Icons.Default.Apps,
            "Calls" to Icons.Default.Call,
            "Settings" to Icons.Default.Settings
        )
    }

    LaunchedEffect(ui.status) {
        if (ui.status.isNotBlank()) {
            snack.showSnackbar(ui.status)
            vm.clearStatus()
        }
    }

    Scaffold(
        containerColor = RavanColors.Bg,
        snackbarHost = { SnackbarHost(snack) },
        bottomBar = {
            NavigationBar(containerColor = RavanColors.Card) {
                tabs.forEachIndexed { i, (label, icon) ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = { tab = i },
                        icon = { Icon(icon, contentDescription = label) },
                        label = { Text(label) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color.White,
                            selectedTextColor = RavanColors.Red,
                            indicatorColor = RavanColors.RedDeep,
                            unselectedIconColor = RavanColors.Muted,
                            unselectedTextColor = RavanColors.Muted
                        )
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> DashboardScreen(vm, actions)
                1 -> ChatScreen(vm, actions)
                2 -> AgentScreen(vm, actions)
                3 -> CallsScreen(vm, actions)
                else -> SettingsScreen(vm, actions)
            }
        }
    }

    val pending = ui.pendingPlan
    if (pending.isNotEmpty()) {
        AlertDialog(
            onDismissRequest = { vm.cancelPending() },
            containerColor = RavanColors.Card,
            titleContentColor = RavanColors.Text,
            textContentColor = RavanColors.Muted,
            title = { Text("Review RAVAN task plan") },
            text = { Text(vm.describePlan(pending)) },
            confirmButton = {
                TextButton(onClick = { vm.confirmPending() }) { Text("Run plan", color = RavanColors.Red) }
            },
            dismissButton = {
                TextButton(onClick = { vm.cancelPending() }) { Text("Cancel", color = RavanColors.Muted) }
            }
        )
    }
}
