package com.ravan.ai.automation

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import android.os.Handler
import android.os.Looper
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.Presentation
import androidx.media3.effect.ScaleAndRotateTransformation
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import java.io.File
import java.io.FileInputStream
import java.util.concurrent.Executors

/**
 * Local video editor. The source video stays on-device; output is saved to Movies/RAVAN AI.
 * Supported edits in this build: trim, 90-degree rotation increments, optional 720p scale, mute.
 */
class VideoEditorEngine(private val context: Context) {
    private val main = Handler(Looper.getMainLooper())

    @OptIn(UnstableApi::class)
    fun export(
        source: Uri,
        startSeconds: Double,
        endSeconds: Double,
        muteAudio: Boolean,
        rotationDegrees: Int,
        outputHeight: Int = 720,
        callback: (Result<Uri>) -> Unit
    ) {
        if (startSeconds < 0 || endSeconds <= startSeconds) {
            callback(Result.failure(IllegalArgumentException("End time must be greater than start time.")))
            return
        }
        val requestedStartMs = (startSeconds * 1000).toLong()
        val requestedEndMs = (endSeconds * 1000).toLong()
        val tempFile = File(context.cacheDir, "ravan_edit_${System.currentTimeMillis()}.mp4")
        val mediaItem = MediaItem.Builder()
            .setUri(source)
            .setClippingConfiguration(
                MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs(requestedStartMs)
                    .setEndPositionMs(requestedEndMs)
                    .build()
            )
            .build()

        val videoEffects = mutableListOf<androidx.media3.common.Effect>()
        if (rotationDegrees % 360 != 0) {
            videoEffects += ScaleAndRotateTransformation.Builder()
                .setRotationDegrees(rotationDegrees.toFloat())
                .build()
        }
        if (outputHeight > 0) videoEffects += Presentation.createForHeight(outputHeight)
        val edited = EditedMediaItem.Builder(mediaItem)
            .setRemoveAudio(muteAudio)
            .setEffects(Effects(emptyList(), videoEffects))
            .build()

        val listener = object : Transformer.Listener {
            override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                val worker = Executors.newSingleThreadExecutor()
                worker.execute {
                    val saved = try {
                        copyToMovies(tempFile)
                    } catch (error: Exception) {
                        Result.failure<Uri>(error)
                    } finally {
                        tempFile.delete()
                    }
                    main.post { callback(saved) }
                    worker.shutdown()
                }
            }

            override fun onError(
                composition: Composition,
                exportResult: ExportResult,
                exportException: ExportException
            ) {
                tempFile.delete()
                callback(Result.failure(exportException))
            }
        }

        try {
            val transformer = Transformer.Builder(context)
                .addListener(listener)
                .build()
            transformer.start(edited, tempFile.absolutePath)
        } catch (error: Exception) {
            tempFile.delete()
            callback(Result.failure(error))
        }
    }

    private fun copyToMovies(tempFile: File): Result<Uri> {
        if (!tempFile.exists() || tempFile.length() == 0L) {
            return Result.failure(IllegalStateException("The video export produced an empty file."))
        }
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "RAVAN_EDITED_${System.currentTimeMillis()}.mp4")
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/RAVAN AI")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val resolver = context.contentResolver
        val destination = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw IllegalStateException("Android could not create the output video in Movies/RAVAN AI.")
        try {
            resolver.openOutputStream(destination, "w")?.use { output ->
                FileInputStream(tempFile).use { input -> input.copyTo(output) }
            } ?: throw IllegalStateException("Could not open the output video for writing.")
            val ready = ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }
            resolver.update(destination, ready, null, null)
            return Result.success(destination)
        } catch (error: Exception) {
            resolver.delete(destination, null, null)
            throw error
        }
    }
}
