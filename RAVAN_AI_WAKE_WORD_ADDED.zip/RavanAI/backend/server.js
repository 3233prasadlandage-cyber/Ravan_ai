'use strict';
/*
 * RAVAN AI backend
 * - Node.js built-in HTTP server (no npm runtime dependencies)
 * - Anthropic Messages API proxy for the Android app
 * - Optional Twilio-compatible, turn-by-turn AI phone receptionist
 *
 * Important: this is not a SIM-call audio interceptor. Cellular call forwarding
 * to a cloud voice provider is required, and only where the carrier/provider
 * permits it. The caller is told they are speaking to an AI.
 */
const http = require('http');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const env = process.env;
const API_KEY = env.ANTHROPIC_API_KEY || '';
const APP_TOKEN = env.APP_TOKEN || '';
const MODEL = env.MODEL || 'claude-sonnet-5-5';
const API_URL = env.ANTHROPIC_URL || 'https://api.anthropic.com/v1/messages';
const PORT = Number(env.PORT || 8080);
const PUBLIC_URL = (env.PUBLIC_URL || '').replace(/\/$/, '');
const DATA_FILE = env.DATA_FILE || path.join(__dirname, 'calls.json');
const CALL_LANG = env.CALL_LANG || 'multi';
const CALL_SPEECH_MODEL = env.CALL_SPEECH_MODEL || 'deepgram_nova-3';
const CALL_SPEECH_TIMEOUT = Number(env.CALL_SPEECH_TIMEOUT || 5);
const SAY_LANG_DEFAULT = env.SAY_LANG_DEFAULT || 'mr-IN';
const SAY_VOICES = {
  'mr-IN': env.SAY_VOICE_MR || '',
  'hi-IN': env.SAY_VOICE_HI || '',
  'en-IN': env.SAY_VOICE_EN || '',
  'en-US': env.SAY_VOICE_EN || '',
  'en-GB': env.SAY_VOICE_EN || '',
};
const GREETING = env.GREETING ||
  'नमस्कार, मी RAVAN AI बोलत आहे, करण यांचा AI सहाय्यक. करण सध्या उपलब्ध नाहीत. तुम्ही मराठी, हिंदी किंवा इंग्रजीत बोलू शकता. काय मदत करू?';
const DISCLOSURE = env.DISCLOSURE ||
  'एक महत्त्वाची माहिती: मी AI सहाय्यक आहे. RAVAN कॉलची ऑडिओ रेकॉर्डिंग साठवत नाही; मात्र तुमचा कॉलर नंबर आणि संभाषणाचा छोटा मजकूर-सारांश करण यांना दाखवला जाईल. दूरध्वनी सेवा पुरवठादार त्यांच्या सेवेनुसार कॉल डेटा प्रक्रिया करू शकतो.';
const ALLOWED_CALL_LANGS = new Set(['multi', 'hi-IN', 'en-IN', 'en-US', 'en-GB']);
const ALLOWED_SAY_LANGS = new Set(['mr-IN', 'hi-IN', 'en-IN', 'en-US', 'en-GB']);
const ALLOWED_SPEECH_MODELS = new Set([
  'default', 'experimental_conversations', 'experimental_utterances',
  'googlev2_long', 'googlev2_short', 'googlev2_telephony',
  'deepgram_nova-2', 'deepgram_nova-3',
]);
const MAX_CALL_TURNS = 8;
const MAX_BODY_BYTES = 100 * 1024;
const MAX_CALLS_IN_MEMORY = 500;

if (!API_KEY || !APP_TOKEN) {
  console.error('Set ANTHROPIC_API_KEY and APP_TOKEN. See .env.example.');
  process.exit(1);
}
if (!ALLOWED_CALL_LANGS.has(CALL_LANG)) {
  console.error(`Unsupported CALL_LANG "${CALL_LANG}". Use multi, hi-IN, en-IN, en-US or en-GB.`);
  process.exit(1);
}
if (!ALLOWED_SPEECH_MODELS.has(CALL_SPEECH_MODEL)) {
  console.error(`Unsupported CALL_SPEECH_MODEL "${CALL_SPEECH_MODEL}".`);
  process.exit(1);
}
if (CALL_LANG === 'multi' && CALL_SPEECH_MODEL !== 'deepgram_nova-3') {
  console.error('CALL_LANG=multi requires CALL_SPEECH_MODEL=deepgram_nova-3.');
  process.exit(1);
}
if (!ALLOWED_SAY_LANGS.has(SAY_LANG_DEFAULT)) {
  console.error(`Unsupported SAY_LANG_DEFAULT "${SAY_LANG_DEFAULT}".`);
  process.exit(1);
}
if (!Number.isInteger(CALL_SPEECH_TIMEOUT) || CALL_SPEECH_TIMEOUT < 1 || CALL_SPEECH_TIMEOUT > 60) {
  console.error('CALL_SPEECH_TIMEOUT must be an integer from 1 to 60.');
  process.exit(1);
}
if (!Number.isInteger(PORT) || PORT < 1 || PORT > 65535) {
  console.error('PORT must be a valid TCP port.');
  process.exit(1);
}

const activeCalls = new Map(); // CallSid -> short-lived conversation, memory only
const finalizedIds = new Set();
const rateHits = new Map();

function send(res, status, type, body) {
  res.writeHead(status, {
    'content-type': type,
    'cache-control': 'no-store',
    'x-content-type-options': 'nosniff',
  });
  res.end(body);
}
function json(res, status, value) {
  send(res, status, 'application/json; charset=utf-8', JSON.stringify(value));
}
function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on('data', (chunk) => {
      size += chunk.length;
      if (size > MAX_BODY_BYTES) {
        reject(Object.assign(new Error('body too large'), { statusCode: 413 }));
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });
    req.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
    req.on('error', reject);
  });
}
function parseRequestBody(raw, contentType) {
  if (contentType.includes('application/json')) {
    try { return raw ? JSON.parse(raw) : {}; }
    catch { throw Object.assign(new Error('invalid JSON'), { statusCode: 400 }); }
  }
  if (contentType.includes('application/x-www-form-urlencoded')) {
    return Object.fromEntries(new URLSearchParams(raw));
  }
  return {};
}
function authorized(req) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : '';
  const a = Buffer.from(token);
  const b = Buffer.from(APP_TOKEN);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}
function rateLimited(req, limit = 30) {
  const ip = (req.socket.remoteAddress || 'unknown').replace(/^::ffff:/, '');
  const now = Date.now();
  const recent = (rateHits.get(ip) || []).filter((t) => now - t < 60_000);
  if (recent.length >= limit) return true;
  recent.push(now);
  rateHits.set(ip, recent);
  if (rateHits.size > 2000) {
    for (const [key, values] of rateHits) {
      if (!values.length || now - values[values.length - 1] > 120_000) rateHits.delete(key);
    }
  }
  return false;
}

async function askClaude(system, messages, maxTokens = 500) {
  const response = await fetch(API_URL, {
    method: 'POST',
    headers: {
      'content-type': 'application/json',
      'x-api-key': API_KEY,
      'anthropic-version': '2023-06-01',
    },
    body: JSON.stringify({ model: MODEL, max_tokens: maxTokens, system, messages }),
    signal: AbortSignal.timeout(35_000),
  });
  if (!response.ok) throw new Error(`AI provider HTTP ${response.status}`);
  const payload = await response.json();
  return (payload.content || [])
    .filter((block) => block.type === 'text')
    .map((block) => block.text)
    .join('')
    .trim();
}

function normalizeMessages(list, maxItems = 20, maxChars = 4000) {
  const out = [];
  for (const item of (Array.isArray(list) ? list : []).slice(-maxItems)) {
    if (!item || typeof item.content !== 'string' || !['user', 'assistant'].includes(item.role)) continue;
    const content = item.content.slice(0, maxChars);
    if (out.length && out[out.length - 1].role === item.role) out[out.length - 1].content += '\n' + content;
    else out.push({ role: item.role, content });
  }
  while (out.length && out[0].role !== 'user') out.shift();
  return out.length && out[out.length - 1].role === 'user' ? out : null;
}
function extractJson(text) {
  const start = text.indexOf('{');
  const end = text.lastIndexOf('}');
  if (start < 0 || end <= start) return null;
  try { return JSON.parse(text.slice(start, end + 1)); } catch { return null; }
}

// ---------- Android app chat ----------
const ACTION_ARGS = {
  open_app: ['name'], find_app: ['name'], youtube: ['query'], camera: [], settings: ['screen'],
  alarm: ['hour', 'minute', 'label'], show_alarms: [], reminder: ['minutes', 'text'],
  open_file: ['query'], share: ['text'], open_url: ['url'],
  schedule_whatsapp_draft: ['phone', 'message', 'time'],
};
const SETTINGS_SCREENS = ['wifi', 'bluetooth', 'display', 'sound', 'battery', 'location',
  'apps', 'notifications', 'storage', 'date', 'airplane', 'main'];
function cleanAction(action) {
  if (!action || typeof action.type !== 'string' || !Object.prototype.hasOwnProperty.call(ACTION_ARGS, action.type)) return null;
  const args = {};
  const source = action.args && typeof action.args === 'object' ? action.args : {};
  for (const key of ACTION_ARGS[action.type]) {
    if (source[key] !== undefined && source[key] !== null) args[key] = String(source[key]).slice(0, 500);
  }
  if (action.type === 'alarm') {
    const hour = Number.parseInt(args.hour, 10);
    const minute = Number.parseInt(args.minute || '0', 10);
    if (!(hour >= 0 && hour <= 23 && minute >= 0 && minute <= 59)) return null;
    args.hour = String(hour); args.minute = String(minute);
  }
  if (action.type === 'reminder') {
    const minutes = Number.parseInt(args.minutes, 10);
    if (!(minutes >= 1 && minutes <= 43200)) return null;
    args.minutes = String(minutes);
  }
  if (action.type === 'settings' && !SETTINGS_SCREENS.includes(args.screen)) args.screen = 'main';
  if (action.type === 'open_app' && !String(args.name || '').trim()) return null;
  if (action.type === 'find_app' && !String(args.name || '').trim()) return null;
  if (action.type === 'open_file' && !String(args.query || '').trim()) return null;
  if (action.type === 'open_url') {
    try {
      const url = new URL(String(args.url || '').trim());
      if (!['http:', 'https:'].includes(url.protocol) || !url.hostname) return null;
      args.url = url.toString().slice(0, 500);
    } catch { return null; }
  }
  if (action.type === 'share' && !String(args.text || '').trim()) return null;
  if (action.type === 'schedule_whatsapp_draft') {
    args.phone = String(args.phone || '').replace(/\D/g, '');
    args.message = String(args.message || '').trim().slice(0, 1500);
    args.time = String(args.time || '').trim();
    if (args.phone.length < 8 || args.phone.length > 15 || !args.message) return null;
    if (!/^(?:[01]\d|2[0-3]):[0-5]\d$/.test(args.time)) return null;
  }
  return { type: action.type, args };
}
function chatSystem(now, language) {
  return `You are RAVAN AI, a personal Android assistant. Users may speak Marathi, Hindi, English or mixed language. Reply in the same language (preferred language: ${language}). Be concise but helpful. Current local time: ${now}.\n` +
    'Return ONLY JSON: {"reply":"text to say","actions":[{"type":"...","args":{...}}]}. Use an empty actions array when no phone action is needed. ' +
    'You may create at most 5 sequential actions, only when the user clearly asks for them. Allowed actions: ' +
    'open_app{name}; find_app{name} (opens official Play Store search; user must review and tap Install); youtube{query}; camera{}; settings{screen}; alarm{hour,minute,label}; ' +
    'show_alarms{}; reminder{minutes,text}; open_file{query}; share{text}; schedule_whatsapp_draft{phone,message,time}. ' +
    `For settings, screen must be one of: ${SETTINGS_SCREENS.join(', ')}. ` +
    'For alarm use 24-hour hour and minute. For reminder minutes must be 1..43200. For schedule_whatsapp_draft, the user must provide the complete international phone number, exact message and 24-hour HH:mm time; it schedules a notification and a pre-filled WhatsApp draft only. Never say that WhatsApp sent it: the user must review and press Send. Never invent phone numbers or missing details; ask a follow-up question instead. ' +
    'The built-in Creator Studio can combine up to 20 user-selected photos/videos into a local MP4, set still-image duration, add one title overlay, choose 16:9 or 9:16, apply simple grayscale/invert/brightness/cinematic presets, add one looping music track, mute source audio, and export. It is not text-to-video generation and does not include advanced multi-track keyframes, crossfades or professional VFX. You may write a script, storyboard, narration and edit plan, but never claim a generative video model rendered it. For photo requests, the app can report face count and general scene/object labels on-device; never identify people or infer names from faces. ' +
    'Do not claim to silently install apps, send WhatsApp messages, control arbitrary third-party app screens, recognise individuals, or perform actions the app cannot do. Never claim an action is complete before the Android app reports the result. If a step opens another app or needs a human choice, mention that clearly. Put app-launch and other hand-off actions last because the Android app pauses the plan after handing control to another app. Prefer the fewest safe actions needed to satisfy the request.';
}

async function handleChat(req, res, body) {
  if (rateLimited(req)) return json(res, 429, { error: 'rate limit' });
  if (!authorized(req)) return json(res, 401, { error: 'unauthorized' });
  const messages = normalizeMessages(body.messages);
  if (!messages) return json(res, 400, { error: 'messages must end with a user message' });
  const language = String(body.language || 'auto').slice(0, 10);
  const now = String(body.now || new Date().toISOString()).slice(0, 64);
  try {
    const raw = await askClaude(chatSystem(now, language), messages, 1000);
    const parsed = extractJson(raw);
    if (!parsed) return json(res, 200, { reply: raw, actions: [], action: null });
    const sourceActions = Array.isArray(parsed.actions)
      ? parsed.actions.slice(0, 5)
      : (parsed.action ? [parsed.action] : []);
    const actions = sourceActions.map(cleanAction).filter(Boolean);
    return json(res, 200, {
      reply: typeof parsed.reply === 'string' ? parsed.reply.slice(0, 4000) : '',
      actions,
      // Retain the old field so an earlier app build can still use the first step.
      action: actions[0] || null,
    });
  } catch (error) {
    console.error('chat error:', error.message);
    return json(res, 502, { error: 'AI service error' });
  }
}

// ---------- call summaries ----------
function loadCalls() {
  try {
    const parsed = JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
    return Array.isArray(parsed) ? parsed : [];
  } catch { return []; }
}
function saveCall(entry) {
  const all = loadCalls();
  all.push(entry);
  fs.mkdirSync(path.dirname(DATA_FILE), { recursive: true });
  fs.writeFileSync(DATA_FILE, JSON.stringify(all.slice(-500)), { mode: 0o600 });
}

// ---------- Twilio-compatible voice receptionist ----------
function validTwilio(req, body) {
  const token = env.TWILIO_AUTH_TOKEN;
  if (!token || !PUBLIC_URL) return false;
  // Twilio signs the externally configured URL plus sorted POST parameters.
  const route = req.url || '/';
  const signedUrl = PUBLIC_URL + route;
  let data = signedUrl;
  for (const key of Object.keys(body).sort()) data += key + String(body[key]);
  const expected = crypto.createHmac('sha1', token).update(data).digest('base64');
  const got = String(req.headers['x-twilio-signature'] || '');
  const a = Buffer.from(expected);
  const b = Buffer.from(got);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}
const xmlEscape = (value) => String(value).replace(/[<>&"']/g, (char) =>
  ({ '<': '&lt;', '>': '&gt;', '&': '&amp;', '"': '&quot;', "'": '&apos;' }[char]));
function say(text, language = SAY_LANG_DEFAULT) {
  const selectedLanguage = ALLOWED_SAY_LANGS.has(language) ? language : SAY_LANG_DEFAULT;
  const voiceName = SAY_VOICES[selectedLanguage] || '';
  const voice = voiceName ? ` voice="${xmlEscape(voiceName)}"` : '';
  return `<Say language="${xmlEscape(selectedLanguage)}"${voice}>${xmlEscape(text)}</Say>`;
}
function gather() {
  return `<Gather input="speech" language="${xmlEscape(CALL_LANG)}" speechModel="${xmlEscape(CALL_SPEECH_MODEL)}" speechTimeout="${CALL_SPEECH_TIMEOUT}" timeout="6" actionOnEmptyResult="true" action="${PUBLIC_URL}/voice/turn" method="POST"/>`;
}
function twiml(res, body) {
  return send(res, 200, 'text/xml; charset=utf-8',
    `<?xml version="1.0" encoding="UTF-8"?><Response>${body}</Response>`);
}
const CALL_SYSTEM = [
  'You are RAVAN AI, an AI receptionist answering a live phone call for Karan, who is currently unavailable.',
  'At the beginning of the call the caller has already been told you are an AI and that a short text summary and caller ID will be shown to Karan.',
  'Be conversational and genuinely respond to what the caller says. Answer ordinary questions about the assistant and the reason for this call. Do not behave like a rigid message form.',
  'Speak in the caller’s language based on their latest utterance (Hindi, English, or another language if the recognizer captured it). Keep each response to one or two short sentences, suitable for telephone audio.',
  'For requests that require Karan’s personal knowledge, decisions, availability, location, or commitments, say you cannot confirm and offer to pass on a message. Never invent facts or make promises on Karan’s behalf.',
  'If useful, ask one natural follow-up question to understand the purpose, urgency, or name for a callback. Do not ask the caller for passwords, OTPs, bank/card details, or other sensitive secrets.',
  'When the caller says goodbye, says there is nothing else, or the message is clear enough, thank them and set end=true. Otherwise continue the conversation and set end=false.',
  'Return ONLY valid JSON in this exact shape: {"reply":"short spoken answer","language":"mr-IN or hi-IN or en-IN","end":true or false}. Use the language the caller is speaking. Do not include markdown or extra text.',
  'Do not claim to transfer the call or contact emergency services. If the caller describes an immediate danger, tell them to contact local emergency services directly.',
].join(' ');

async function handleVoiceIncoming(req, res, body) {
  const sid = String(body.CallSid || '').slice(0, 128);
  if (!sid) return twiml(res, say('Sorry, this call could not be identified.') + '<Hangup/>');
  if (!activeCalls.has(sid)) {
    if (activeCalls.size >= MAX_CALLS_IN_MEMORY) {
      return twiml(res, say('Sorry, the AI assistant is temporarily busy. Please try again later.') + '<Hangup/>');
    }
    activeCalls.set(sid, {
      from: String(body.From || 'unknown').slice(0, 64),
      turns: [], callerTurns: 0, emptyTurns: 0, startedAt: Date.now(), done: false,
    });
  }
  return twiml(res, say(GREETING) + say(DISCLOSURE) + gather() +
    say('I did not receive a response. Please call again later. Thank you.') + '<Hangup/>');
}

async function handleVoiceTurn(res, body) {
  const sid = String(body.CallSid || '').slice(0, 128);
  const call = activeCalls.get(sid);
  if (!call || call.done) {
    return twiml(res, say('This AI session has ended. Please call again if you need help.') + '<Hangup/>');
  }
  const speech = String(body.SpeechResult || '').trim().slice(0, 1200);
  if (!speech) {
    call.emptyTurns++;
    if (call.emptyTurns >= 2) {
      return twiml(res, say('I still could not hear you. I will let Karan know that a call came in. Thank you.') + '<Hangup/>');
    }
    return twiml(res, say('Sorry, I did not catch that. Could you please say it once more?') + gather() +
      say('Thank you for calling. Goodbye.') + '<Hangup/>');
  }

  call.emptyTurns = 0;
  call.callerTurns++;
  call.turns.push({ role: 'user', content: speech });
  let reply = '';
  let shouldEnd = false;
  try {
    const messages = normalizeMessages(call.turns, 16, 1200);
    const raw = messages ? await askClaude(CALL_SYSTEM, messages, 260) : '';
    const parsed = extractJson(raw);
    if (parsed && typeof parsed.reply === 'string') {
      reply = parsed.reply.trim();
      const requestedLanguage = String(parsed.language || SAY_LANG_DEFAULT);
      var replyLanguage = ALLOWED_SAY_LANGS.has(requestedLanguage) ? requestedLanguage : SAY_LANG_DEFAULT;
      shouldEnd = parsed.end === true;
    } else {
      reply = raw.replace(/\s*\[END\]\s*/ig, '').trim();
      shouldEnd = /\[END\]/i.test(raw);
      var replyLanguage = SAY_LANG_DEFAULT;
    }
  } catch (error) {
    console.error('call turn error:', error.message);
    reply = 'Sorry, I am having a technical issue. I will pass on that you called, but please try again later for a conversation.';
    shouldEnd = true;
  }

  if (!reply) {
    reply = 'Thank you for calling. I will pass on that you called.';
    shouldEnd = true;
  }
  if (call.callerTurns >= MAX_CALL_TURNS) {
    reply += ' Thank you. I will pass your message to Karan.';
    shouldEnd = true;
  }
  call.turns.push({ role: 'assistant', content: reply });
  if (shouldEnd) call.done = true;
  return twiml(res, say(reply, replyLanguage) + (shouldEnd ? '<Hangup/>' : gather() +
    say('Thank you for calling. Goodbye.') + '<Hangup/>'));
}

async function finalizeCall(sid) {
  if (!sid || finalizedIds.has(sid)) return;
  const call = activeCalls.get(sid);
  if (!call) return;
  finalizedIds.add(sid);
  if (finalizedIds.size > 2000) finalizedIds.delete(finalizedIds.values().next().value);
  activeCalls.delete(sid);
  const callerLines = call.turns.filter((turn) => turn.role === 'user').map((turn) => turn.content);
  if (!callerLines.length) return; // Do not create an empty call record.

  const transcript = call.turns.map((turn) =>
    `${turn.role === 'user' ? 'Caller' : 'RAVAN AI'}: ${turn.content}`).join('\n').slice(0, 10_000);
  let result = {
    purpose: callerLines[0].slice(0, 160),
    summary: callerLines.join(' / ').slice(0, 600),
  };
  try {
    const raw = await askClaude(
      'Summarise this AI-receptionist phone conversation for Karan. Return ONLY JSON with keys: ' +
      '{"purpose":"short topic","summary":"2-3 sentences in English","name":"caller name or unknown","urgency":"low|normal|high"}. ' +
      'Do not invent information. Do not include sensitive secrets if present.',
      [{ role: 'user', content: transcript }], 300);
    const parsed = extractJson(raw);
    if (parsed) {
      result = {
        purpose: String(parsed.purpose || result.purpose).slice(0, 200),
        summary: `${String(parsed.name || 'Unknown caller').slice(0, 80)} (${String(parsed.urgency || 'normal').slice(0, 20)} urgency). ${String(parsed.summary || result.summary).slice(0, 500)}`,
      };
    }
  } catch (error) {
    console.error('call summary error:', error.message);
  }
  saveCall({
    id: sid,
    number: call.from,
    purpose: result.purpose,
    summary: result.summary,
    ts: Date.now(),
  });
}

async function handleRequest(req, res) {
  const parsedUrl = new URL(req.url, 'http://localhost');
  const route = parsedUrl.pathname;
  const method = req.method || 'GET';

  if (method === 'GET' && route === '/health') return json(res, 200, { ok: true, service: 'ravan-ai-backend' });

  if (method === 'POST' && route === '/chat') {
    const raw = await readBody(req);
    const body = parseRequestBody(raw, req.headers['content-type'] || '');
    return handleChat(req, res, body);
  }

  if (method === 'GET' && route === '/calls') {
    if (rateLimited(req, 60)) return json(res, 429, { error: 'rate limit' });
    if (!authorized(req)) return json(res, 401, { error: 'unauthorized' });
    const since = Math.max(0, Number.parseInt(parsedUrl.searchParams.get('since') || '0', 10) || 0);
    return json(res, 200, { calls: loadCalls().filter((item) => Number(item.ts) > since) });
  }

  if (method === 'POST' && ['/voice/incoming', '/voice/turn', '/voice/status'].includes(route)) {
    const raw = await readBody(req);
    const body = parseRequestBody(raw, req.headers['content-type'] || '');
    if (!validTwilio(req, body)) return send(res, 403, 'text/plain; charset=utf-8', 'forbidden');
    if (route === '/voice/incoming') return handleVoiceIncoming(req, res, body);
    if (route === '/voice/turn') return handleVoiceTurn(res, body);
    if (route === '/voice/status') {
      if (['completed', 'busy', 'no-answer', 'failed', 'canceled'].includes(String(body.CallStatus || ''))) {
        await finalizeCall(String(body.CallSid || ''));
      }
      return send(res, 204, 'text/plain; charset=utf-8', '');
    }
  }

  return json(res, 404, { error: 'not found' });
}

const server = http.createServer((req, res) => {
  handleRequest(req, res).catch((error) => {
    if (res.headersSent) return res.destroy();
    console.error('request error:', error.message);
    json(res, error.statusCode || 500, { error: error.statusCode === 400 ? 'invalid request' : 'server error' });
  });
});
server.listen(PORT, '0.0.0.0', () => {
  console.log(`RAVAN AI backend listening on port ${PORT}`);
  console.log(`Voice recognition: ${CALL_LANG} / ${CALL_SPEECH_MODEL}; default voice: ${SAY_LANG_DEFAULT}; public URL: ${PUBLIC_URL ? 'configured' : 'not set'}.`);
});
