'use strict';
// Dependency-free offline smoke test: fake Anthropic endpoint + real RAVAN backend.
const http = require('http');
const crypto = require('crypto');
const { spawn } = require('child_process');
const fs = require('fs');
const assert = require('assert');

const MOCK_PORT = 9911;
const PORT = 9912;
const TOKEN = 'test-token';
const TWILIO_TOKEN = 'test-twilio-secret';
const PUBLIC = `http://127.0.0.1:${PORT}`;
const DATA = '/tmp/ravan-test-calls.json';
try { fs.unlinkSync(DATA); } catch {}

const mock = http.createServer((req, res) => {
  let raw = '';
  req.on('data', (chunk) => { raw += chunk; });
  req.on('end', () => {
    const request = JSON.parse(raw || '{}');
    const system = request.system || '';
    const latest = (request.messages || []).filter((m) => m.role === 'user').slice(-1)[0]?.content || '';
    let text;
    if (system.startsWith('Summarise')) {
      text = '{"purpose":"Courier delivery","summary":"Caller says a courier is at the gate and asks for a callback.","name":"Ravi","urgency":"normal"}';
    } else if (system.includes('live phone call')) {
      if (/रवी|Ravi/i.test(latest)) text = JSON.stringify({ reply: 'नमस्ते रवी, तुम्ही कोणत्या कामासाठी फोन केला आहे?', language: 'mr-IN', end: false });
      else if (/कुरियर|courier/i.test(latest)) text = JSON.stringify({ reply: 'समजले. आजच उत्तर देणे आवश्यक आहे का?', language: 'mr-IN', end: false });
      else text = JSON.stringify({ reply: 'धन्यवाद. मी तुमचा संदेश करण यांच्यापर्यंत पोहोचवेन.', language: 'mr-IN', end: true });
    } else if (/two-step plan|multi step plan/i.test(latest)) {
      text = JSON.stringify({
        reply: 'मी आधी YouTube उघडेन आणि नंतर कॅमेरा उघडेन.',
        actions: [
          { type: 'youtube', args: { query: 'water leakage detection' } },
          { type: 'camera', args: {} },
        ],
      });
    } else if (/install|download|capcut/i.test(latest)) {
      text = JSON.stringify({ reply: 'मी Play Store मध्ये CapCut शोधत आहे. Install तुम्हीच confirm करा.', action: { type: 'find_app', args: { name: 'CapCut' } } });
    } else if (/schedule whatsapp/i.test(latest)) {
      text = JSON.stringify({
        reply: 'मी WhatsApp draft reminder schedule करेन. पाठवण्यासाठी तुम्हाला Send दाबावे लागेल.',
        actions: [{ type: 'schedule_whatsapp_draft', args: { phone: '+91 98765 43210', message: 'Happy Birthday!', time: '00:00' } }],
      });
    } else if (/invalid website/i.test(latest)) {
      text = JSON.stringify({ reply: 'हा URL सुरक्षित HTTP(S) वेबसाइट नाही.', actions: [{ type: 'open_url', args: { url: 'javascript:alert(1)' } }] });
    } else if (/open website/i.test(latest)) {
      text = JSON.stringify({ reply: 'मी ही वेबसाइट browser मध्ये उघडेन.', actions: [{ type: 'open_url', args: { url: 'https://example.com/' } }] });
    } else if (/invalid whatsapp plan/i.test(latest)) {
      text = JSON.stringify({
        reply: 'फोन नंबर नसल्यामुळे draft schedule करता येणार नाही.',
        actions: [{ type: 'schedule_whatsapp_draft', args: { message: 'Hello', time: '00:00' } }],
      });
    } else if (/six step plan/i.test(latest)) {
      text = JSON.stringify({
        reply: 'मी फक्त पाच सुरक्षित टप्पे परत करू शकतो.',
        actions: Array.from({ length: 6 }, (_, i) => ({ type: 'camera', args: { step: String(i + 1) } })),
      });
    } else {
      text = '{"reply":"अलार्म सेट करने की स्क्रीन खोल रहा हूँ","action":{"type":"alarm","args":{"hour":7,"minute":30,"label":"gym"}}}';
    }
    res.writeHead(200, { 'content-type': 'application/json' });
    res.end(JSON.stringify({ content: [{ type: 'text', text }] }));
  });
}).listen(MOCK_PORT, '127.0.0.1');

const srv = spawn(process.execPath, ['server.js'], {
  cwd: __dirname,
  env: {
    ...process.env,
    ANTHROPIC_API_KEY: 'test-key',
    APP_TOKEN: TOKEN,
    ANTHROPIC_URL: `http://127.0.0.1:${MOCK_PORT}/v1/messages`,
    PORT: String(PORT),
    PUBLIC_URL: PUBLIC,
    TWILIO_AUTH_TOKEN: TWILIO_TOKEN,
    DATA_FILE: DATA,
    CALL_LANG: 'multi',
    CALL_SPEECH_MODEL: 'deepgram_nova-3',
  },
  stdio: 'ignore',
});

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
function signature(route, params) {
  let data = PUBLIC + route;
  for (const key of Object.keys(params).sort()) data += key + String(params[key]);
  return crypto.createHmac('sha1', TWILIO_TOKEN).update(data).digest('base64');
}
async function postTwilio(route, params) {
  return fetch(PUBLIC + route, {
    method: 'POST',
    headers: {
      'content-type': 'application/x-www-form-urlencoded',
      'x-twilio-signature': signature(route, params),
    },
    body: new URLSearchParams(params).toString(),
  });
}

(async () => {
  try {
    let ready = false;
    for (let i = 0; i < 30; i++) {
      try { ready = (await fetch(PUBLIC + '/health')).ok; } catch {}
      if (ready) break;
      await sleep(100);
    }
    assert(ready, 'backend must start');

    let response = await fetch(PUBLIC + '/chat', {
      method: 'POST', headers: { 'content-type': 'application/json' }, body: '{}',
    });
    assert.equal(response.status, 401, 'chat without app token must be 401');

    response = await fetch(PUBLIC + '/chat', {
      method: 'POST',
      headers: { 'content-type': 'application/json', authorization: `Bearer ${TOKEN}` },
      body: JSON.stringify({
        messages: [
          { role: 'assistant', content: 'नमस्कार' },
          { role: 'user', content: 'सकाळी साडेसातला अलार्म लाव' },
        ],
        language: 'mr-IN', now: '2026-11-24T12:00:00+05:30',
      }),
    });
    let payload = await response.json();
    assert.equal(response.status, 200);
    assert.equal(payload.action.type, 'alarm');
    assert.equal(payload.action.args.hour, '7');

    response = await fetch(PUBLIC + '/chat', {
      method: 'POST',
      headers: { 'content-type': 'application/json', authorization: `Bearer ${TOKEN}` },
      body: JSON.stringify({
        messages: [{ role: 'user', content: 'Install CapCut' }],
        language: 'en-IN', now: '2026-11-24T12:00:00+05:30',
      }),
    });
    payload = await response.json();
    assert.equal(response.status, 200);
    assert.equal(payload.action.type, 'find_app', 'AI planner may only open Play Store search, not silently install');
    assert.equal(payload.action.args.name, 'CapCut');
    assert.equal(payload.actions.length, 1, 'legacy one-action response must be normalised to an action list');

    response = await fetch(PUBLIC + '/chat', {
      method: 'POST',
      headers: { 'content-type': 'application/json', authorization: `Bearer ${TOKEN}` },
      body: JSON.stringify({ messages: [{ role: 'user', content: 'two-step plan' }], language: 'en-IN', now: '2026-11-24T12:00:00+05:30' }),
    });
    payload = await response.json();
    assert.equal(response.status, 200);
    assert.equal(payload.actions.length, 2, 'backend must return a bounded multi-action plan');
    assert.equal(payload.actions[0].type, 'youtube');
    assert.equal(payload.actions[1].type, 'camera');

    response = await fetch(PUBLIC + '/chat', {
      method: 'POST',
      headers: { 'content-type': 'application/json', authorization: `Bearer ${TOKEN}` },
      body: JSON.stringify({ messages: [{ role: 'user', content: 'open website' }], language: 'en-IN', now: '2026-11-24T12:00:00+05:30' }),
    });
    payload = await response.json();
    assert.equal(response.status, 200);
    assert.equal(payload.actions[0].type, 'open_url');
    assert.equal(payload.actions[0].args.url, 'https://example.com/');

    response = await fetch(PUBLIC + '/chat', {
      method: 'POST',
      headers: { 'content-type': 'application/json', authorization: `Bearer ${TOKEN}` },
      body: JSON.stringify({ messages: [{ role: 'user', content: 'invalid website' }], language: 'en-IN', now: '2026-11-24T12:00:00+05:30' }),
    });
    payload = await response.json();
    assert.equal(payload.actions.length, 0, 'backend must reject non-HTTP(S) URLs');

    response = await fetch(PUBLIC + '/chat', {
      method: 'POST',
      headers: { 'content-type': 'application/json', authorization: `Bearer ${TOKEN}` },
      body: JSON.stringify({ messages: [{ role: 'user', content: 'schedule whatsapp' }], language: 'en-IN', now: '2026-11-24T12:00:00+05:30' }),
    });
    payload = await response.json();
    assert.equal(response.status, 200);
    assert.equal(payload.actions[0].type, 'schedule_whatsapp_draft');
    assert.equal(payload.actions[0].args.phone, '919876543210');
    assert.equal(payload.actions[0].args.time, '00:00');

    response = await fetch(PUBLIC + '/chat', {
      method: 'POST',
      headers: { 'content-type': 'application/json', authorization: `Bearer ${TOKEN}` },
      body: JSON.stringify({ messages: [{ role: 'user', content: 'invalid whatsapp plan' }], language: 'en-IN', now: '2026-11-24T12:00:00+05:30' }),
    });
    payload = await response.json();
    assert.equal(response.status, 200);
    assert.equal(payload.actions.length, 0, 'backend must reject a draft without recipient phone number');

    response = await fetch(PUBLIC + '/chat', {
      method: 'POST',
      headers: { 'content-type': 'application/json', authorization: `Bearer ${TOKEN}` },
      body: JSON.stringify({ messages: [{ role: 'user', content: 'six step plan' }], language: 'en-IN', now: '2026-11-24T12:00:00+05:30' }),
    });
    payload = await response.json();
    assert.equal(payload.actions.length, 5, 'backend must limit plans to at most five actions');

    response = await postTwilio('/voice/incoming', { CallSid: 'CA1', From: '+919999999999' });
    let xml = await response.text();
    assert(xml.includes('मी RAVAN AI') || xml.includes('RAVAN AI'), 'AI greeting must be played');
    assert(xml.includes('मी AI सहाय्यक आहे'), 'AI disclosure must be played');
    assert(xml.includes('language="multi"') && xml.includes('speechModel="deepgram_nova-3"'), 'multilingual STT must be configured');
    assert(xml.includes('<Gather'), 'incoming call must begin collecting speech');

    response = await postTwilio('/voice/turn', {
      CallSid: 'CA1', From: '+919999999999', SpeechResult: 'मेरा नाम रवी है',
    });
    xml = await response.text();
    assert(xml.includes('तुम्ही कोणत्या कामासाठी फोन केला आहे?'), 'AI must ask a relevant follow-up');
    assert(xml.includes('Say language="mr-IN"'), 'AI must choose Marathi speech output for Marathi reply');
    assert(xml.includes('<Gather'), 'AI must continue the conversation');

    response = await postTwilio('/voice/turn', {
      CallSid: 'CA1', From: '+919999999999', SpeechResult: 'कुरियर गेट पर आया है',
    });
    xml = await response.text();
    assert(xml.includes('आजच उत्तर देणे आवश्यक आहे का?'), 'AI must respond to caller meaning');
    assert(xml.includes('<Gather'), 'AI must allow another caller turn');

    response = await postTwilio('/voice/turn', {
      CallSid: 'CA1', From: '+919999999999', SpeechResult: 'नहीं, बस बता दीजिए। धन्यवाद।',
    });
    xml = await response.text();
    assert(xml.includes('<Hangup/>'), 'AI should end after caller closes');
    assert(!xml.includes('[END]'), 'internal end marker must not be spoken');

    await postTwilio('/voice/status', { CallSid: 'CA1', CallStatus: 'completed', From: '+919999999999' });
    await sleep(300);
    response = await fetch(PUBLIC + '/calls', { headers: { authorization: `Bearer ${TOKEN}` } });
    payload = await response.json();
    assert.equal(payload.calls.length, 1, 'one call summary should be saved');
    assert.equal(payload.calls[0].number, '+919999999999');
    assert.equal(payload.calls[0].purpose, 'Courier delivery');

    response = await fetch(PUBLIC + '/voice/incoming', {
      method: 'POST', headers: { 'content-type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({ CallSid: 'CA2', From: '+910000000000' }).toString(),
    });
    assert.equal(response.status, 403, 'unsigned request must be forbidden');

    console.log('ALL BACKEND TESTS PASSED');
  } catch (error) {
    console.error('TEST FAILED:', error.stack || error.message);
    process.exitCode = 1;
  } finally {
    srv.kill();
    mock.close();
    try { fs.unlinkSync(DATA); } catch {}
  }
})();
